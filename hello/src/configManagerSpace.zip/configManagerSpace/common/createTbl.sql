
--create database ConfigManagerDB
--sp_addlogin confmgr, ??????
--sp_changedbowner  confmgr
--sp_modifylogin confmgr, defdb, ConfigManagerDB


--create table FilterTagPrecedence (
create table FilterTag (
--	id numeric(8,0) identity primary key,
	id numeric(8,0) primary key,

	filterTag varchar(50) not null,
	precedence numeric(5,2) not null,
	derivation varchar(200),
	updatedBy varchar(20),
	lastUpdated DateTime,
	comment varchar(800),
	active char(1),

	unique (precedence),
	unique (filterTag)
)

create table Filter (
	id numeric(8,0) primary key,

	filterId varchar(50) not null,
	conditions varchar(800) not null,
	description varchar(800),
	updatedBy varchar(20),
	lastUpdated DateTime,
	active char(1),

	unique(filterId) 
)

create table Property (
	id numeric(8,0) primary key,

	instance varchar(20),
	filterId varchar(50) not null,
	propertyId varchar(200) not null,
	propertyValue varchar(200),
	override char(1) null,
	startTime DateTime null,
	endTime DateTime null,
	updatedBy varchar(20),
	lastUpdated DateTime,
	comment varchar(800),
	active char(1), 

	unique(instance, filterId, propertyId, startTime, endTime) 
)

create table PropertyTag (	
	propertyId	varchar(200) primary key,
	fixTag	int  null,
	name	varchar(255) ,
	updatedBy	varchar(50),
	lastUpdated	datetime
)

ALTER TABLE Property ADD CONSTRAINT fk_FilterId FOREIGN KEY (filterId) REFERENCES Filter(filterId)
ALTER TABLE Property ADD CONSTRAINT fk_property FOREIGN KEY (propertyId) REFERENCES PropertyTag(propertyId)

create table AlgoStrategy (
	strategy	varchar(50) primary key,
	tag6061	int  null,
	description	varchar(255),
	updatedBy	varchar(50),
	lastUpdated	datetime,
)

create table AlgoTagMapping (
	id	int primary key,
	strategy	varchar(50) not null,
	propertyId	varchar(200) not null,
	country	varchar(50) null,
	updatedBy	varchar(50),
	lastUpdated	datetime,
	active	char
)

ALTER TABLE AlgoTagMapping ADD CONSTRAINT fk_algoTag FOREIGN KEY (algoTag) REFERENCES PropertyTag(propertyId)
ALTER TABLE AlgoTagMapping ADD CONSTRAINT fk_strategy FOREIGN KEY (strategy) REFERENCES AlgoStrategy(strategy)



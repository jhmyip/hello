/*
create table TestParent (
	id numeric(8,0) identity primary key,
	name varchar(20) not null,
	unique(name)
)

create table TestChild (
	id numeric(8,0) identity primary key,
	name varchar(20) not null,
	parentId numeric(8,0) not null,
	unique(name)
)
ALTER TABLE TestChild ADD CONSTRAINT fk_parent foreign key (parentId) references TestParent(id)
*/

--sp_help TestParent
--insert into TestParent (name) values ("John")
--insert into TestParent (name) values ("Peter")
/*
insert into TestChild (name, parentId) values ("Mary", 1)
insert into TestChild (name, parentId) values ("May", 1)
insert into TestChild (name, parentId) values ("Peter", 2)
insert into TestChild (name, parentId) values ("Tom", 2)
insert into TestChild (name, parentId) values ("David", 2)
*/





create table TestParent (
	id numeric(8,0) primary key,
	name varchar(20) not null,
	unique(name)
)

create table TestChild (
	id numeric(8,0) primary key,
	name varchar(20) not null,
	parentId numeric(8,0) not null,
	unique(name)
)
ALTER TABLE TestChild ADD CONSTRAINT fk_parent foreign key (parentId) references TestParent(id)


insert into TestParent (id, name) values (1, "John")
insert into TestParent (id, name) values (2, "Peter")

insert into TestChild (id, name, parentId) values (1, "Mary", 1)
insert into TestChild (id, name, parentId) values (2, "May", 1)
insert into TestChild (id, name, parentId) values (3, "Peter", 2)
insert into TestChild (id, name, parentId) values (4, "Tom", 2)
insert into TestChild (id, name, parentId) values (5, "David", 2)
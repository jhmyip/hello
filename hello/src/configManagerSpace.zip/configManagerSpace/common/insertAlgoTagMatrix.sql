
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("Strategy", 6061, "Strategy", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("EndTime", 126, "EndTime/Expire Time", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("StartTime", 168, "StartTime/Effective Time", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("MinQty", 110, "MinQty", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("MaxVol", 6064, "Max%Vol", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("ExecStyle", 6065, "ExecStyle", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("MinVol", 6067, "Min%Vol", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("DispDepths", 6070, "DispDepths", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("MarketView", 6073, "MarketView", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("DisplayQty", 6075, "DisplayQty", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("DispQtyAdjust", 6076, "DispQtyAdjust%", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("AutoDisplay", 6077, "AutoDisplay", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("TriggerQty", 6078, "TriggerQty", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("DontTakeQty", 6079, "DontTakeQty", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("IWouldUnits", 6205, "I Would Units", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("IWouldValue", 6206, "I Would Value", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("IWouldPct", 6207, "I Would %", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("Field1", 6223, "Field1", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("Field2", 6224, "Field2", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("Field3", 6225, "Field3", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("Field4", 6226, "Field4", user_name(), getdate())
insert into PropertyTag (propertyId, fixTag, name, updatedBy, lastUpdated) values
("Field5", 6227, "Field5", user_name(), getdate())




insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("DMA", 0, "DMA", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("VWAP", 1, "VWAP", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("POV", 5, "POV", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("DynamicPOV", 11, "Dynamic POV", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("TWAP", 6, "TWAP", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Active", 7, "Active", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Iceberg", 8, "Iceberg", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Pegging", 9, "Pegging", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("AggressiveSS", 12, "AggressiveSS", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Opportunistic", 14, "Opportunistic", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Sniper", 20, "Sniper", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Custom1", 21, "Custom1", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Custom2", 22, "Custom2", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Custom3", 23, "Custom3", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Custom4", 24, "Custom4", user_name(), getdate())
insert into AlgoStrategy (strategy, tag6061, description, updatedBy, lastUpdated) values
("Custom5", 25, "Custom5", user_name(), getdate())


/*
insert into AlgoTagMatrix (id, strategy, algoTag, country, updatedBy, lastUpdated, active) values
(1, "VWAP", "MaxVol", null, user_name(), getdate(), "Y")
insert into AlgoTagMatrix (id, strategy, algoTag, country, updatedBy, lastUpdated, active) values
(2, "POV", "MaxVol", null, user_name(), getdate(), "Y")
insert into AlgoTagMatrix (id, strategy, algoTag, country, updatedBy, lastUpdated, active) values
(3, "POV", "MinVol", null, user_name(), getdate(), "Y")
insert into AlgoTagMatrix (id, strategy, algoTag, country, updatedBy, lastUpdated, active) values
(4, "TWAP", "MaxVol", null, user_name(), getdate(), "Y")
insert into AlgoTagMatrix (id, strategy, algoTag, country, updatedBy, lastUpdated, active) values
(5, "POV", "DisplayQty", null, user_name(), getdate(), "Y")

insert into AlgoTagMatrix (id, strategy, algoTag, country, updatedBy, lastUpdated, active) values
(6, "VWAP", "EndTime", null, user_name(), getdate(), "Y")
insert into AlgoTagMatrix (id, strategy, algoTag, country, updatedBy, lastUpdated, active) values
(7, "POV", "EndTime", null, user_name(), getdate(), "Y")
insert into AlgoTagMatrix (id, strategy, algoTag, country, updatedBy, lastUpdated, active) values
(8, "TWAP", "EndTime", null, user_name(), getdate(), "Y")
*/

insert into AlgoTagMapping (id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(1, 'VWAP', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping (id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(2, 'VWAP', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping (id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(3, 'VWAP', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping (id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(4, 'VWAP', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping (id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(5, 'POV', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping (id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(6, 'POV', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping (id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(7, 'POV', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping (id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(8, 'DynamicPOV', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(9, 'DynamicPOV', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(10, 'DynamicPOV', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(11, 'DynamicPOV', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(12, 'DynamicPOV', 'MinVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(13, 'DynamicPOV', 'MarketView', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(14, 'TWAP', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(15, 'TWAP', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(16, 'TWAP', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(17, 'TWAP', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(18, 'Active', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(19, 'Active', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(20, 'Active', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(21, 'Iceberg', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(22, 'Iceberg', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(23, 'Iceberg', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(24, 'Iceberg', 'DisplayQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(25, 'Iceberg', 'DispQtyAdjust', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(26, 'Pegging', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(27, 'Pegging', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(28, 'Pegging', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(29, 'Pegging', 'DispDepths', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(30, 'Pegging', 'DisplayQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(31, 'Pegging', 'DispQtyAdjust', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(32, 'Opportunistic', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(33, 'Opportunistic', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(34, 'Opportunistic', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(35, 'Opportunistic', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(36, 'AggressiveSS', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(37, 'AggressiveSS', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(38, 'AggressiveSS', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(39, 'Sniper', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(40, 'Sniper', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(41, 'Sniper', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(42, 'Sniper', 'DisplayQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(43, 'Sniper', 'DispQtyAdjust', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(44, 'Sniper', 'AutoDisplay', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(45, 'Sniper', 'TriggerQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(46, 'Sniper', 'DontTakeQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(47, 'Custom1', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(48, 'Custom1', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(49, 'Custom1', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(50, 'Custom2', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(51, 'Custom2', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(52, 'Custom2', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(53, 'Custom2', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(54, 'Custom2', 'Field1', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(55, 'Custom2', 'Field2', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(56, 'Custom2', 'Field3', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(57, 'Custom2', 'Field4', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(58, 'Custom3', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(59, 'Custom3', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(60, 'Custom3', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(61, 'Custom3', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(62, 'Custom3', 'MinVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(63, 'Custom3', 'MarketView', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(64, 'Custom3', 'DisplayQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(65, 'Custom3', 'TriggerQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(66, 'Custom3', 'IWouldUnits', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(67, 'Custom3', 'IWouldValue', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(68, 'Custom3', 'IWouldPct', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(69, 'Custom3', 'Field1', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(70, 'Custom3', 'Field2', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(71, 'Custom3', 'Field3', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(72, 'Custom3', 'Field4', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(73, 'Custom4', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(74, 'Custom4', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(75, 'Custom4', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(76, 'Custom4', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(77, 'Custom4', 'DisplayQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(78, 'Custom4', 'TriggerQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(79, 'Custom4', 'Field1', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(80, 'Custom4', 'Field2', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(81, 'Custom4', 'Field3', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(82, 'Custom4', 'Field4', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(83, 'Custom5', 'EndTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(84, 'Custom5', 'StartTime', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(85, 'Custom5', 'MaxVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(86, 'Custom5', 'ExecStyle', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(87, 'Custom5', 'MinVol', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(88, 'Custom5', 'DispDepths', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(89, 'Custom5', 'DisplayQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(90, 'Custom5', 'DispQtyAdjust', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(91, 'Custom5', 'TriggerQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(92, 'Custom5', 'DontTakeQty', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(93, 'Custom5', 'IWouldUnits', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(94, 'Custom5', 'IWouldValue', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(95, 'Custom5', 'IWouldPct', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(96, 'Custom5', 'Field1', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(97, 'Custom5', 'Field2', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(98, 'Custom5', 'Field3', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(99, 'Custom5', 'Field4', null, user_name(), getdate(), "Y")
insert into AlgoTagMapping(id, strategy, propertyId, country, updatedBy, lastUpdated, active) values 
(100, 'Custom5', 'Field5', null, user_name(), getdate(), "Y")


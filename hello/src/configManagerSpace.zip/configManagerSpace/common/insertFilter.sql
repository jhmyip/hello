/*
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
("region", 1.00, "com.daiwacm.reference.stock.getRegion", user_name(), getdate(), "region code", "Y")
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
("country", 2.00, "com.daiwacm.reference.stock.getExchange", user_name(), getdate(), "country code", "Y")
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
("exchange", 3.00, "com.daiwacm.reference.stock.getExchange", user_name(), getdate(), "exchange code", "Y")
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('venue', 4, 'com.daiwacm.util.order.getVenue', user_name(), getdate(), 'internal venue code', 'Y')
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('strategy', 5, 'fix.6061', user_name(), getdate(), 'strategy code', 'Y')
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('client', 6, 'order.client', user_name(), getdate(), 'client acct', 'Y')
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('trader', 7, 'com.daiwacm.util.order.getTrader', user_name(), getdate(), 'trader id', 'Y')
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('sector', 8, 'com.daiwacm.reference.stock.getSector', user_name(), getdate(), 'sector of the stock', 'Y')
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('mktcap', 8.1, 'com.daiwacm.reference.stock.getMarketCap', user_name(), getdate(), 'market cap', 'Y')
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('symbol', 9, 'fix.Symbol', user_name(), getdate(), 'stock symbol', 'Y')
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('Side', 10, 'order.side', user_name(), getdate(), 'order side', 'Y')
insert into FilterTagPrecedence (filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
('ordType', 11, 'fix.OrdType', user_name(), getdate(), 'order type', 'Y')


insert into Filter (filterId, conditions, description, updatedBy, lastUpdated, active) values
("HK_POV", "strategy=POV;country=HK", "testing 123", user_name(), getdate(), "Y")
insert into Filter (filterId, conditions, description, updatedBy, lastUpdated, active) values
("HSBC_POV", "strategy=POV; symbol=0005.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (filterId, conditions, description, updatedBy, lastUpdated, active) values
("CMOD_POV", "strategy=POV; symbol=0941.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (filterId, conditions, description, updatedBy, lastUpdated, active) values
("CK_POV", "strategy=POV; symbol=0001.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (filterId, conditions, description, updatedBy, lastUpdated, active) values
("CK_VWAP", "strategy=VWAP; symbol=0001.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (filterId, conditions, description, updatedBy, lastUpdated, active) values
("HSBC_VWAP", "strategy=VWAP; symbol=0005.HK;", "testing", user_name(), getdate(), "Y")

insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'HK_POV', 'max_volume_cap', '30', '', null, null, user_name(), getdate(), 'max vol cap', 'Y')
insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'HK_POV', 'moo', 'false', null, null, null, user_name(), getdate(), 'region code', 'Y')
insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'HK_POV', 'moc', 'false', null, null, null, user_name(), getdate(), 'region code', 'Y')
insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'HK_POV', 'trading_style', '1', null, null, null, user_name(), getdate(), 'trading style for HK POV', 'Y')
insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'HSBC_POV', 'trading_style', '2', null, null, null, user_name(), getdate(), 'trading style for HSBC POV', 'Y')
insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'CK_POV', 'trading_style', '3', null, null, null, user_name(), getdate(), 'trading style for CK POV', 'Y')
insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'CMOD_POV', 'trading_style', '3', null, null, null, user_name(), getdate(), 'trading style for China Mod POV', 'Y')

insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'CK_VWAP', 'trading_style', '3', null, null, null, user_name(), getdate(), 'trading style for CK VW', 'Y')

insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'HSBC_VWAP', 'trading_style', '3', null, null, null, user_name(), getdate(), 'trading style for HSBC VW', 'Y')

insert into Property (instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
('*', 'HSBC_VWAP', 'moo', 'false', null, null, null, user_name(), getdate(), 'bypass moo part for HSBC VW', 'Y')
*/
/*
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(1, "region", 1.00, "com.daiwacm.reference.stock.getRegion", user_name(), getdate(), "region code", "Y")
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(2, "country", 2.00, "com.daiwacm.reference.stock.getExchange", user_name(), getdate(), "country code", "Y")
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(3, "exchange", 3.00, "com.daiwacm.reference.stock.getExchange", user_name(), getdate(), "exchange code", "Y")
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(4, 'venue', 4, 'com.daiwacm.util.order.getVenue', user_name(), getdate(), 'internal venue code', 'Y')
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(5, 'strategy', 5, 'fix.6061', user_name(), getdate(), 'strategy code', 'Y')
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(6, 'client', 6, 'order.client', user_name(), getdate(), 'client acct', 'Y')
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(7, 'trader', 7, 'com.daiwacm.util.order.getTrader', user_name(), getdate(), 'trader id', 'Y')
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(8, 'sector', 8, 'com.daiwacm.reference.stock.getSector', user_name(), getdate(), 'sector of the stock', 'Y')
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(9, 'mktcap', 8.1, 'com.daiwacm.reference.stock.getMarketCap', user_name(), getdate(), 'market cap', 'Y')
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(10, 'symbol', 9, 'fix.Symbol', user_name(), getdate(), 'stock symbol', 'Y')
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(11, 'Side', 10, 'order.side', user_name(), getdate(), 'order side', 'Y')
insert into FilterTagPrecedence (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(12,'ordType', 11, 'fix.OrdType', user_name(), getdate(), 'order type', 'Y')
*/


insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(1, "region", 1, "com.daiwacm.dats.ConfigManager.Stock.getRegion", user_name(), getdate(), "region code", "Y")
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(2, "country", 2, "com.daiwacm.dats.ConfigManager.Stock.getCountry", user_name(), getdate(), "country code", "Y")
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(3, "exchange", 3, "com.daiwacm.dats.ConfigManager.Stock.getExchange", user_name(), getdate(), "exchange code", "Y")
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(4, 'venue', 4, 'com.daiwacm.dats.ConfigManager.Order.getVenue', user_name(), getdate(), 'internal venue code', 'Y')
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(5, 'strategy', 5, 'fix.6061', user_name(), getdate(), 'strategy code', 'Y')
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(6, 'client', 6, 'order.client', user_name(), getdate(), 'client acct', 'Y')
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(7, 'trader', 7, 'com.daiwacm.dats.ConfigManager.Order.getTrader', user_name(), getdate(), 'trader id', 'Y')
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(8, 'sector', 8, 'com.daiwacm.dats.ConfigManager.Stock.getSector', user_name(), getdate(), 'sector of the stock', 'Y')
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(9, 'mktcap', 8.1, 'com.daiwacm.dats.ConfigManager.Stock.getMarketCap', user_name(), getdate(), 'market cap', 'Y')
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(10, 'symbol', 9, 'fix.Symbol', user_name(), getdate(), 'stock symbol', 'Y')
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(11, 'side', 10, 'order.side', user_name(), getdate(), 'order side', 'Y')
insert into FilterTag (id, filterTag, precedence, derivation, updatedBy, lastUpdated, comment, active) values
(12,'ordType', 11, 'fix.OrdType', user_name(), getdate(), 'order type', 'Y')


insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(1, "HK_POV", "strategy=POV;country=HK", "testing 123", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(2, "HSBC_POV", "strategy=POV; symbol=0005.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(3, "CMOD_POV", "strategy=POV; symbol=0941.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(4, "CK_POV", "strategy=POV; symbol=0001.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(5, "CK_VWAP", "strategy=VWAP; symbol=0001.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(6, "HSBC_VWAP", "strategy=VWAP; symbol=0005.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(7, "PCCW_VWAP", "strategy=VWAP; symbol=0008.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(8, "PCCW_VWAP", "strategy=POV; symbol=0008.HK;", "testing", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(9, "HK_VWAP", "strategy=VWAP; exchange=HKSE;", "testing", user_name(), getdate(), "Y")
insert into Filter (id, filterId, conditions, description, updatedBy, lastUpdated, active) values
(10, "HSBC_SSVWAP", "strategy=VWAP; symbol=0005.HK; side=SS", "HSBC SS VWAP", user_name(), getdate(), "Y")

insert into Property (id, instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
(1, '*', 'HK_POV', 'MaxVol', '30', '', null, null, user_name(), getdate(), 'max vol cap', 'Y')
insert into Property (id, instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
(2, '*', 'HK_POV', 'ExecStyle', 'NORM', null, null, null, user_name(), getdate(), 'trading style for HK POV', 'Y')
insert into Property (id, instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
(3, '*', 'HSBC_POV', 'ExecStyle', 'PASS', null, null, null, user_name(), getdate(), 'trading style for HSBC POV', 'Y')
insert into Property (id, instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
(4, '*', 'CK_POV', 'ExecStyle', 'AGGR', null, null, null, user_name(), getdate(), 'trading style for CK POV', 'Y')
insert into Property (id, instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
(5, '*', 'CMOD_POV', 'ExecStyle', 'AGGR', null, null, null, user_name(), getdate(), 'trading style for China Mod POV', 'Y')
insert into Property (id, instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
(6, '*', 'CK_VWAP', 'ExecStyle', 'AGGR', null, null, null, user_name(), getdate(), 'trading style for CK VW', 'Y')
insert into Property (id, instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy, lastUpdated,comment,active) values
(7, '*', 'HSBC_VWAP', 'ExecStyle', 'NORM', null, null, null, user_name(), getdate(), 'trading style for HSBC VW', 'Y')

package com.daiwacm.dats.configManager;

import java.math.BigDecimal;
import java.util.Map;

import com.daiwacm.dats.configManager.common.DuplicateTagException;
import com.daiwacm.dats.configManager.common.IConfigurable;
import com.daiwacm.dats.configManager.common.InvalidConditionException;
import com.daiwacm.dats.configManager.common.InvalidDerivationException;
import com.daiwacm.dats.configManager.common.UnknownFilterTagException;
import com.daiwacm.dats.configManager.common.UnknownOperatorException;
import com.daiwacm.dats.configManager.common.UnknownTagException;

public interface ConfigManager {
	
	// APIs for querying properties and enriching orders

	public IConfigurable enrichOrder(IConfigurable order);

	public Property getProperty(IConfigurable order, String propertyId, boolean wildcard);
	public Map<String, Property> getProperties(IConfigurable order, String[] propertyIds);

	public Property getProperty(String exchange, String propertyId);
	public Property getProperty(String propertyId);

	// APIs for updating configuration

	public void createFilterTag(String filterTag, BigDecimal precedence, String derivation, String comment) 
    	throws DuplicateTagException, NoSuchMethodException, InvalidDerivationException;

    public PropertyTag createPropertyTag(String propertyId, int fixTag, String propertyName) 
    	throws DuplicateTagException;
    
    public void createFilter(String filterId, String filterConditions, String description) 
		throws DuplicateTagException, UnknownOperatorException, UnknownFilterTagException, InvalidConditionException;

    public Property createProperty(String instance, String filterId, String propertyId, String propertyValue, Character override, String comment) 
        	throws UnknownTagException;

    public Filter updateFilter(String filterId, String filterConditions, String comment);
    public Property updateProperty(String filterId, String propertyId, String propertyValue, Character override, String comment);
    
    public FilterTag removeFilterTag(String filterTag);
    public PropertyTag removePropertyTag(String propertyId);
    public Filter removeFilter(String filterId);
    public Property removeProperty(String instance, String filterId, String propertyId);

}

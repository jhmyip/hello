package com.daiwacm.dats.configManager;


import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daiwacm.dats.configManager.common.IConfigurable;
import com.daiwacm.dats.configManager.common.InvalidConditionException;
import com.daiwacm.dats.configManager.common.UnknownFilterTagException;
import com.daiwacm.dats.configManager.common.UnknownOperatorException;
import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceRouting;


/**
 * @author johnnyy
 *
 */
@Entity
@Table(name="Filter")
@SpaceClass
public class Filter implements Comparable<Filter> {

    private static final Logger log = LoggerFactory.getLogger(Filter.class);
	
	private Integer id;

	private String filterId;
	private String conditions;
	private String description;
	private String updatedBy;
	private Date lastUpdated;
	private char active;
	
	@Transient
	private FilterConditions filterConditions;
     
    public Filter() {
    	active = 'Y'; // default is active
    }
	
    public Filter(Integer id, String filterId, String conditions, String description, String updatedBy, Date lastUpdated, char active) {
        this.id = id;
        this.filterId = filterId;
        this.conditions = conditions;
        this.description = description;
        this.updatedBy = updatedBy;
        this.lastUpdated = lastUpdated;
        this.active = active;
    }
    
    public Filter(Integer id, String filterId, String conditions, String description) {
        this.id = id;
        this.filterId = filterId;
        this.conditions = conditions;
        this.description = description;
		updatedBy = "confmgr";
		lastUpdated = Calendar.getInstance().getTime();
        active = 'Y';
    }
    
    @Id
    @SpaceId(autoGenerate = false)
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getFilterId() {
        return filterId;
    }
    
    public void setFilterId(String filterId) {
        this.filterId = filterId;
    }
    public String getConditions() {
        return conditions;
    }
    
    public void setConditions(String conditions) {
    	this.conditions = conditions;
    }

	public void initFilterConditions(MainConfigManager configManager) throws UnknownOperatorException, UnknownFilterTagException, InvalidConditionException {
		filterConditions = new FilterConditions(configManager, conditions);
		log.info("Loaded filter {}, conditions={}", filterId, filterConditions);
	}

	public String getDescription() {
		return description;
	}
    
    public void setDescription(String description) {
        this.description = description;
    }
    public String getUpdatedBy() {
        return updatedBy;
    }
    
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    public Date getLastUpdated() {
        return lastUpdated;
    }
    
    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    @SpaceRouting
    public char getActive() {
        return active;
    }
    
    public void setActive(char active) {
        this.active = active;
    }
    
	@Override
	public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("Filter [")
	      .append("id=").append(id)
	      .append(", filterId=").append(filterId)
	      .append(", conditions=").append(conditions)
	      .append(", updatedBy=").append(updatedBy)
	      .append(", lastUpdated=").append(lastUpdated)
	      .append(", active=").append(active)
	      .append("]");
	    return sb.toString();
	}
    
	@Override
	public boolean equals(Object obj) {
		return obj!=null && 
				id == ((Filter)obj).id &&
				filterId.equals(((Filter)obj).filterId) &&
				active == ((Filter)obj).active;
	}

	@Override
	public int hashCode() {
		return (id+filterId+active).hashCode();
	}
	
	public boolean matches(MainConfigManager configManager, IConfigurable order, boolean wildcard) {
	    return filterConditions.matches(configManager, order, wildcard);
	}
	
    @Override
    public int compareTo(Filter o) {
        return filterConditions.compareTo(o.filterConditions);
    }
}
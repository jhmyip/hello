package com.daiwacm.dats.configManager;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daiwacm.dats.configManager.common.Condition;
import com.daiwacm.dats.configManager.common.IConfigurable;
import com.daiwacm.dats.configManager.common.InvalidConditionException;
import com.daiwacm.dats.configManager.common.UnknownFilterTagException;
import com.daiwacm.dats.configManager.common.UnknownOperatorException;

public class FilterConditions implements Comparable<FilterConditions> {

    private static final Logger log = LoggerFactory.getLogger(FilterConditions.class);
	
    private TreeSet<Condition> sortedConditions = new TreeSet<Condition>(new Comparator<Condition>() {
        // sorted in descending order of precedence
		@Override
		public int compare(Condition o1, Condition o2) {
			return - o1.compareTo(o2);
		}
	});
	
	public FilterConditions(MainConfigManager configManager, String conditionsStr) 
	        throws UnknownOperatorException, UnknownFilterTagException, InvalidConditionException {

        String[] conditionStrings = conditionsStr.split("; *");

        for (String conditionStr : conditionStrings) {
            if (conditionStr.trim().isEmpty()) {
                log.warn("Skipping empty condition");
                continue;
            }
            
            Condition.ConditionOperator operator = null;
            
            for (Condition.ConditionOperator currentOperator : Condition.ConditionOperator.values) {
                if (conditionStr.contains(currentOperator.getOperator())) {
                    operator = currentOperator;
                    break;
                }
            }
            if (operator == null) {
                throw new UnknownOperatorException(conditionStr);
            }
            
            String[] parts = conditionStr.split(operator.getOperator());
            if (parts.length != 2) {
                throw new InvalidConditionException(conditionStr);
            }
            
            String tagStr = parts[0].trim();
            FilterTag tag = configManager.getFilterTag(tagStr);
            if (tag == null) {
                throw new UnknownFilterTagException(tagStr);
            }
            
            String value = parts[1].trim();
            sortedConditions.add(Condition.create(tag, configManager.getFilterTagDerivation(tag), 
                           operator, value));
        }
    }

	// Perform matching of FilterConditions against the given order template, wildcard or exact
	public boolean matches(MainConfigManager configManager, IConfigurable order, boolean wildcard) {
        for (Condition condition : sortedConditions) {
            if (!condition.eval(order, wildcard)) {
                return false;
            }
        }
        return true;
	}
	
	@Override
    public int compareTo(FilterConditions filterConditions) {
		Iterator<Condition> i0 = sortedConditions.iterator();
		Iterator<Condition> i1 = filterConditions.sortedConditions.iterator();
		
		while (i0.hasNext() && i1.hasNext()) {
			FilterTag tag = i0.next().getTag();
			FilterTag otherTag = i1.next().getTag();
            
            int result = tag.compareTo(otherTag);
            if (result != 0) {
                return result;
            }
		}
        if (i1.hasNext()) {
            return -1;
        } else if (i0.hasNext()) {
            return 1;
        }
		
        // consider operator precedence if two filterConditions defined with same set of filterTags
		i0 = sortedConditions.iterator();
		i1 = filterConditions.sortedConditions.iterator();
		while (i0.hasNext() && i1.hasNext()) {
            int result = i0.next().compareTo(i1.next());
            if (result != 0) {
                return result;
            }
		}
        
        return 0;
    }
	
	public String toString() {
	    return ArrayUtils.toString(sortedConditions.toArray(new Condition[sortedConditions.size()]));
	}
}

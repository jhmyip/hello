package com.daiwacm.dats.configManager;


import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceRouting;


@Entity
@Table(name="FilterTag")
@SpaceClass
public class FilterTag implements Comparable<FilterTag> {
    
    private Integer id;
    private String filterTag;
    private BigDecimal precedence;
    private String derivation;
	private String updatedBy;
    private Date lastUpdated;
    private String comment;
    private char active;

    public FilterTag() {
    	active = 'Y'; // default is active
    }

    public FilterTag(Integer id, String filterTag, BigDecimal precedence, String derivation, String comment) {
        active = 'Y';
        this.id = id;
        this.filterTag = filterTag;
        this.precedence = precedence;
        this.derivation = derivation;
		updatedBy = "confmgr";
		lastUpdated = Calendar.getInstance().getTime();
        this.comment = comment;
     }

    public FilterTag(Integer id, String filterTag, BigDecimal precedence, String derivation, String comment, Date lastUpdated, char active, String updatedBy) {
       this(id, filterTag, precedence, derivation, comment);
       this.updatedBy = updatedBy;
       this.lastUpdated = lastUpdated;
       this.active = active;
    }
    
    @Id 
    @SpaceId(autoGenerate = false)
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getFilterTag() {
        return filterTag;
    }
    
    public void setFilterTag(String filterTag) {
        this.filterTag = filterTag;
    }
    
    public BigDecimal getPrecedence() {
        return precedence;
    }
    public void setPrecedence(BigDecimal precedence) {
        this.precedence = precedence;
    }

    public String getDerivation() {
        return derivation;
    }
    public void setDerivation(String derivation) {
        this.derivation = derivation;
    }
    
    public String getUpdatedBy() {
        return updatedBy;
    }
    
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    public Date getLastUpdated() {
        return lastUpdated;
    }
    
    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    @SpaceRouting
    public char getActive() {
        return active;
    }
    
    public void setActive(char active) {
        this.active = active;
    }
    
	@Override
	public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("FilterTag [")
	      .append("id=").append(id)
	      .append(", filterTag=").append(filterTag)
	      .append(", precedence=").append(precedence)
	      .append(", derivation=").append(derivation)
	      .append(", updatedBy=").append(updatedBy)
	      .append(", lastUpdated=").append(lastUpdated)
	      .append(", comment=").append(comment)
	      .append(", active=").append(active)
	      .append("]");
	    return sb.toString();
	}

	@Override
	public int compareTo(FilterTag filterTag) {
		return precedence.compareTo(filterTag.getPrecedence());
	}
}
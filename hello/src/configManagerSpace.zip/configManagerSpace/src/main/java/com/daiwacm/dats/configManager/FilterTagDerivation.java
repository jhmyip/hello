package com.daiwacm.dats.configManager;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daiwacm.dats.configManager.common.IConfigurable;
import com.daiwacm.dats.configManager.common.InvalidDerivationException;
import com.daiwacm.dats.configManager.util.ConfigUtils;
import com.daiwacm.dats.refdata.model.interfaces.Product;

public class FilterTagDerivation {
    
    private static final Logger log = LoggerFactory.getLogger(FilterTagDerivation.class);
	
	private Integer fieldNum;
	private Method[] derivationMethods;
	
	private static String getGetter(String field) {
	    return "get" + Character.toUpperCase(field.charAt(0)) + field.substring(1);
	}
	
	public FilterTagDerivation(Method method) {
	    derivationMethods = new Method[] { method };
	}
	
	/**
	 * Parse the derivation string and identify the proper method from the configurableClass
	 * 
	 *  Format of the derivation
	 *  	object.<<field>>			: refers to a field from the object of the configurableClass
	 *  	object.product.<<field>>	: refers to a product attribute for the stock contained in the object of the configurableClass 
	 *  	other format 				: assumes referring to the full path of the derivation method 
	 * @param configurableClass 
	 * @param derivationPath 
	 *  
	 */
	public FilterTagDerivation(Class<? extends IConfigurable> configurableClass, String derivationPath) 
	        throws InvalidDerivationException {
		String[] paths = derivationPath.split("\\.");
		
		try {
    		if (paths[0].equals("product")) {
			    String methodName = getGetter(paths[1]);
			    derivationMethods = new Method[] { configurableClass.getMethod("getProduct"),
			                                       Product.class.getMethod(methodName) };
    		} else if (paths[0].equals("object")){
				derivationMethods = new Method[] { configurableClass.getMethod(getGetter(paths[1])) };
    		} else if (paths[0].equals("fix")) {
    			if (paths[1].matches("[0-9]*")) {
    				fieldNum = Integer.parseInt(paths[1]);
    			} else {
    				fieldNum = ConfigUtils.getFixTagNum(paths[1]);
    				if (fieldNum == null) {
    					throw new InvalidDerivationException(derivationPath);
    				}
    			}
    			
				derivationMethods = new Method[] { configurableClass.getMethod("getField", int.class) };
    		} else {
    			try {
    			    Class<?> derivationClass = Class.forName(derivationPath.substring(0, derivationPath.lastIndexOf('.')));
    			    derivationMethods = new Method[] { derivationClass.getMethod(paths[paths.length-1]) };
    			} catch (ClassNotFoundException e) {
    			    throw new InvalidDerivationException(derivationPath);
    			}
    		}
		} catch (NoSuchMethodException e) {
		    throw new InvalidDerivationException(derivationPath + ": " + e.getMessage());
		}
		
		Class<?> dType = getFilterTagType();
        if (dType!=null && ! (Number.class.isAssignableFrom(dType) || String.class == dType) ) {
            log.warn("Convert unsupported return type {} for derivation {} to string", dType, derivationPath);
        }
	}
	
	/**
	 * Derive the tag value from the given object based on the configured Derivation 
	 * @param obj
	 * @return derived result
	 */
	public Object derive(IConfigurable obj) {
		try {
			if (derivationMethods.length > 1) {
				Product p = (Product) derivationMethods[0].invoke(obj);
				if (p==null) {
					log.warn("product is null in 'derive'!!");
					return null;
				} else
					return derivationMethods[1].invoke(p);
			} else if (fieldNum != null ) {
				return derivationMethods[0].invoke(obj, fieldNum);
			} else {
				return derivationMethods[0].invoke(obj);
			}
		} catch (InvocationTargetException e) {
			log.warn("{} in derivationMethods - {} {}", new Object[] {e.getClass().getSimpleName(), derivationMethods[0].getName(), derivationMethods.length>1 ? derivationMethods[1].getName() : null});
		} catch (IllegalAccessException e) {
			log.error("Problem in derive", e);
		}
		return null;
	}
	
	public Class<?> getFilterTagType() {
		return derivationMethods[derivationMethods.length-1].getReturnType();
	}
}

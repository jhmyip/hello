package com.daiwacm.dats.configManager;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.annotation.PostConstruct;

import org.openspaces.core.GigaSpace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.daiwacm.dats.configManager.common.ConfigurableObject;
import com.daiwacm.dats.configManager.common.DuplicateTagException;
import com.daiwacm.dats.configManager.common.IConfigurable;
import com.daiwacm.dats.configManager.common.InvalidDerivationException;
import com.daiwacm.dats.configManager.common.UnConfigurableException;
import com.daiwacm.dats.configManager.common.UnknownTagException;
import com.daiwacm.dats.configManager.util.ConfigUtils;
import com.daiwacm.dats.configManager.util.IdGenerator;
import com.daiwacm.dats.configManager.util.SpaceBasedIdGenerator;
import com.daiwacm.dats.refdata.model.Equity;
import com.daiwacm.dats.refdata.model.interfaces.Product;
import com.j_spaces.core.client.UpdateModifiers;


/**
 * <p>
 * Configuration Manager
 * </p>
 * @author johnnyy
 *
 */
public class MainConfigManager implements ConfigManager {

	private static final Logger log = LoggerFactory.getLogger(ConfigManager.class);

	@Autowired 
	@Qualifier("cfgGigaSpace")
	private GigaSpace cfgGigaSpace;

	private IdGenerator idgFilterTag;
	private IdGenerator idgFilter;
	private IdGenerator idgProperty;
	private Boolean usePropertyTagFixIfUndefined = false;

	private Class<? extends IConfigurable> configurableClass;
	private Map<String, Method> configurableProperties;

    private Map<String, FilterTag> filterTagMap;
    private Map<String, Method> filterTagMethods;
    private Map<FilterTag, FilterTagDerivation> filterTagDerivations;
	private Map<String, List<Property>> propertyIdToPropertiesMap; 
    private Map<String, List<Property>> filterIdToPropertiesMap;
    private Map<String, Filter> filterIdToFilterMap;
    
    private IConfigurable template = null;
    private Method setExchangeMethod = null;

	@PostConstruct
	public void init() {
	    log.info("Initializing configManager with configurableClass={}", configurableClass);

	    cfgGigaSpace.getSpace().setUpdateModifiers(UpdateModifiers.NO_RETURN_VALUE | UpdateModifiers.UPDATE_OR_WRITE);
	    
        idgFilterTag = new SpaceBasedIdGenerator(cfgGigaSpace, FilterTag.class.getName());
        idgFilter = new SpaceBasedIdGenerator(cfgGigaSpace, Filter.class.getName());
        idgProperty = new SpaceBasedIdGenerator(cfgGigaSpace, Property.class.getName());

        configurableProperties = ConfigUtils.getConfigurableProperties(configurableClass);
	    
        filterTagMethods = ConfigUtils.getConfigurableTagMethods(configurableClass);
        filterTagMap = new TreeMap<String, FilterTag>();
        filterTagDerivations = new TreeMap<FilterTag, FilterTagDerivation>();
        propertyIdToPropertiesMap = new HashMap<String, List<Property>>();
        filterIdToPropertiesMap = new HashMap<String, List<Property>>();
        filterIdToFilterMap = new HashMap<String, Filter>();
        
        FilterTag[] filterTagList = cfgGigaSpace.readMultiple(new FilterTag(), Integer.MAX_VALUE);
        log.info("Loading filter tags", filterTagDerivations.size());
        for (FilterTag filterTag : filterTagList) {
            addFilterTag(filterTag);
        }
        log.debug("Loaded {} filter tags", filterTagDerivations.size());
	    
        log.info("Loading filters");
		for (Filter filter : cfgGigaSpace.readMultiple(new Filter(), Integer.MAX_VALUE)) {
            addFilter(filter);
        }
		
		log.info("Loading properties");
        for (Property property : cfgGigaSpace.readMultiple(new Property(), Integer.MAX_VALUE)) {
            updateProperty(property);
        }
        
        Set<String> filtersToRemove = new HashSet<String>();
        for (Filter filter : filterIdToFilterMap.values()) {
            if (!filterIdToPropertiesMap.containsKey(filter.getFilterId())) {
                filtersToRemove.add(filter.getFilterId());
            }
        }
        
        for (String filterId : filtersToRemove) {
            log.warn("Removing filter with no properties {}", filterId);
            filterIdToFilterMap.remove(filterId);
        }
        log.debug("Loaded {} filters", filterIdToFilterMap.size());
        log.debug("Loaded {} properties", propertyIdToPropertiesMap.size());
        
        try {
            template = configurableClass.newInstance();
        } catch (Exception e) {
            log.error("Failed to get instance for {}: {}", configurableClass.getName(), e.getMessage());
        }
        
        try { 
            setExchangeMethod = configurableClass.getMethod("setExchange", String.class);
        } catch (NoSuchMethodException e) {
            try {
                setExchangeMethod = configurableClass.getMethod("setProduct", Product.class);
            } catch (NoSuchMethodException e2) {
                log.error("Could not find setExchange or setProduct method on {}", configurableClass.getCanonicalName());
            }
        }
        
        log.info("ConfigManager initialized");
	}

	/**
	 * Apply the defaulting/override based on the filtering logic to the given order. 
	 * using default mode 
	 * 
	 * @param order
	 * @return the enriched order 
	 */
	@Override
	public IConfigurable enrichOrder(IConfigurable order) {
	    log.debug("Enriching {}", order);
        Collection<Property> sortedProperties = getSortedProperties(order, null);
        StringBuilder propertiesSb = new StringBuilder();
        for (Property property : sortedProperties) {
            applyProperty(order, property, propertiesSb);
        }
        log.debug("Enriched with [{}]", propertiesSb);
    	return order;
	}
	
	// 1) get subset of filters that match the order, or all if it is null
	// 3) sort by precedence
	// 4) get properties of filters, higher precedence filters take priority for duplicate propertyIds
	// 5) sort properties using compareTo
	private static final Comparator<Filter> reverseFilterComparator = new Comparator<Filter>() {
        @Override
        public int compare(Filter o1, Filter o2) {
            return o2.compareTo(o1);
        }
    };
    private Collection<Property> getSortedProperties(IConfigurable order, String[] propertyIds) {
        
        Set<Filter> matchingFilters = new HashSet<Filter>();
        Set<String> matchingFilterNames = new HashSet<String>();
        
        if (propertyIds != null && propertyIds.length > 0) {
            for (String propertyId : propertyIds) {
                List<Property> propertiesList = propertyIdToPropertiesMap.get(propertyId);
                if (propertiesList == null) {
                    log.warn("No property for id {}", propertyId);
                    continue;
                }
                
                for (Property property : propertiesList) {
                    Filter filter = filterIdToFilterMap.get(property.getFilterId());
                    if (!matchingFilters.contains(filter) && filter.matches(this, order, false)) {
                        matchingFilters.add(filter);
                        matchingFilterNames.add(filter.getFilterId());
                    }
                }
            }
        } else {
            for (Filter filter : filterIdToFilterMap.values()) {
                if (!matchingFilters.contains(filter) && filter.matches(this, order, false)) {
                    matchingFilters.add(filter);
                    matchingFilterNames.add(filter.getFilterId());
                }
            }
        }
        
        Filter[] filters = matchingFilters.toArray(new Filter[matchingFilters.size()]);
        Arrays.sort(filters, reverseFilterComparator);
        Map<String, Property> propertiesMap = new HashMap<String, Property>();
        for (Filter filter : filters) {
            List<Property> list = filterIdToPropertiesMap.get(filter.getFilterId());
            if (list == null) {
                // all properties for filter have been removed
                continue;
            }
            
            for (Property property : list) {
                Property addedProperty = propertiesMap.get(property.getPropertyId());
                boolean newPropertyGreaterThan = addedProperty != null && addedProperty.compareTo(property) < 0;
                if (addedProperty == null || newPropertyGreaterThan) {
                    if (newPropertyGreaterThan) {
                        log.error("Property {} set by more than one matching filter, fix this asap.", addedProperty.getPropertyId());
                    }
                    propertiesMap.put(property.getPropertyId(), property);
                }
            }
        }
        
        log.debug("Matching filters: {}", matchingFilterNames);
        
        return propertiesMap.values();
    }
    
    private Map<String, Integer> fixTagCache = new ConcurrentHashMap<String, Integer>();
    
	@SuppressWarnings({ "unchecked", "rawtypes" })
    private void applyProperty(IConfigurable order, Property property, StringBuilder sb) {
		String propertyTag = property.getPropertyId();
		Object currentVal = null;
		Integer fixTag = fixTagCache.get(propertyTag);
	    if (fixTag == null) {
			String getterName = "get" + Character.toUpperCase(propertyTag.charAt(0)) + propertyTag.substring(1);
			try {
    			Method getter = configurableClass.getMethod(getterName);
    			currentVal = ConfigUtils.invoke(getter, order);
			} catch (NoSuchMethodException e) {
			    // use fix tag
			    fixTag = ConfigUtils.getFixTagNum(property, usePropertyTagFixIfUndefined);
			    if (fixTag != null && fixTag > 0) {
			        fixTagCache.put(propertyTag, fixTag);
			    } else {
			        log.error("FixTag {} for property '{}' is invalid. failed to get value", fixTag, propertyTag);
			        return;
			    }
			}
	    }
		
		if (fixTag != null) {
		    currentVal = order.getField(fixTag);
		}
		
		if (currentVal != null && !property.isOverrideProperty() ) {
		    sb.append(propertyTag + "=(Skipped) ");
            return;
		}
		
		String propertyValue = property.getPropertyValue();
		if (fixTag != null) {
		    sb.append(propertyTag + "=" + propertyValue + " ");
            order.setField(fixTag, propertyValue);
            return;
        }
		
		Method setter = configurableProperties.get(propertyTag);
		if (setter != null) {
			Class<?> retType = setter.getParameterTypes()[0];
		    sb.append(propertyTag + "=" + propertyValue + " ");
	        try {
	            if (String.class.isAssignableFrom(retType)) {
	                setter.invoke(order, propertyValue);
	            } else if (Integer.class.isAssignableFrom(retType)) {
	                setter.invoke(order, Integer.parseInt(propertyValue));
	            } else if (Double.class.isAssignableFrom(retType)) {
	                setter.invoke(order, Double.parseDouble(propertyValue));
	            } else if (Enum.class.isAssignableFrom(retType)) {
	                setter.invoke(order, Enum.valueOf((Class)retType, propertyValue));
	            } else {
	                log.error("Unsupported value type {}, skip property {}", retType, propertyTag);
	            }
	        } catch (Exception e) {
	            log.error("", e);
	        }
		} else { 
		    log.error("Could not find setter for {}", propertyTag);
		}
		    
	}
	
	@Override
	public Map<String, Property> getProperties(IConfigurable order, String[] propertyIds) {
		log.debug("Getting properties for order [{}]", order);
		
		Map<String, Property> results = new HashMap<String, Property>();
    	Collection<Property> properties = getSortedProperties(order, propertyIds);
    	for (String propertyId : propertyIds) {
        	for (Property property : properties) {
        	    if (property.getPropertyId().equals(propertyId)) {
        	        results.put(propertyId, property);
        	        break;
        	    }
        	}
    	}
    	
		return results;
	}
	
	/**
	 * Get property value based on the given order by going through the filtering logic. 
	 * It will refer to the argument "override", when specified, to determine if order property is overridden or not.
	 * @param order
	 * @param propertyId
	 * @param wildcard
	 * @return
	 */
	@Override
	public Property getProperty(IConfigurable order, String propertyId, boolean wildcard) {
		// read all property objects with propertyId
    	List<Filter> filters = new ArrayList<Filter>();
		
    	// all properties applicable to the given order/strategy
    	for (Property property : propertyIdToPropertiesMap.get(propertyId)) {
    		Filter filter = filterIdToFilterMap.get(property.getFilterId());

    		// evaluate filter
    		if (order == null || filter.matches(this, order, wildcard)) {
    		    log.debug("Filter {} passed", filter.getFilterId());
    		    filters.add(filter);
    		}
    	}
		
		logFilterList("Number of passed filter", filters);
    	
    	Filter selected = ConfigUtils.selectFilter(filters, wildcard);
    	if (selected == null) {
    		return null;
    	}
    	
    	for (Property p : propertyIdToPropertiesMap.get(propertyId)) {
    	    if (p.getFilterId().equals(selected.getFilterId())) {
    	        return p;
    	    }
    	}
    	
    	return null;
	}
	
	private void logFilterList(String heading, List<Filter> list) {
		if (!log.isDebugEnabled()) {
		    return;
		}
		
		StringBuilder sb = new StringBuilder(heading);
		sb.append(": ").append(list.size());
    	for (Filter f : list) {
    		sb.append(" [").append(f.getId()).append(" ").append(f.getFilterId()).append("]");
    	}
    	log.debug(sb.toString());
	}

	/**
	 * Get property value based on the given country or exchange (only HKSE at the moment) by going through the filtering logic. 
	 */
	@Override
	public Property getProperty(String exchange, String propertyId) {
	    if (setExchangeMethod == null || template == null) {
	        log.error("Cannot get property for setExchangeMethod {} template {}", setExchangeMethod, template);
	        return null;
	    }
	    
	    try {
	        if (setExchangeMethod.getName().equals("setExchange")) {
	            setExchangeMethod.invoke(template, exchange);
	        } else {
	            Equity equity = new Equity();
	            equity.setCompositeExchangeCode(exchange);
	            setExchangeMethod.invoke(template, (Product)equity);
	        }
	    } catch (Exception e) {
	        log.error("failed to invoke method {} for {}", new Object[] {
	                setExchangeMethod.getName(), configurableClass.getName() }, e.getMessage());
	        return null;
	    }
	    
        log.debug("Exchange set {} ", exchange);
        return getProperty(template, propertyId, true);
	}

	/**
	 * Get the default property value by going through wild card filtering.
	 * 
	 * @param property
	 * @return
	 */
	@Override
	public Property getProperty(String propertyId) {
		return getProperty(null, propertyId, true);
	}
		
    private void updatePropertyMap(Map<String, List<Property>> map, Property property, String id) {
		List<Property> list = map.get(id);
		if (list == null) {
			list = new CopyOnWriteArrayList<Property>();
			map.put(id, list);
		}
		
		for (int i = 0; i < list.size(); i++) { 
			Property p1 = list.get(i);
			if (p1.getId().equals(property.getId())) {
				list.set(i,  property);
				log.debug("replace [{}]", property);
				return;
			}
		}
		list.add(property);
    }

    private void removePropertyMapEntry(Map<String, List<Property>> map, Property property, String id) {
		List<Property> list = map.get(id);
		if (list == null) {
		    return;
		}
		
		for (Property p : list) {
			if (p.getId().equals(property.getId())) {
				list.remove(p);
				break;
			}
		}
		
		if (list.isEmpty()) {
			map.remove(id);
		}
    }
    
    // updatePropertyMap invoked by PropertyUpdateNotifier
    public void updateProperty(Property property) {
        
        if (!filterIdToFilterMap.containsKey(property.getFilterId())) {
            log.error("Ignoring property {} for invalid filter {}", property.getPropertyId(), property.getFilterId());
            return;
        }
        
        if (!property.isValid()) {
            log.warn("Skipping invalid property {}", property);
            return;
        }
        
        PropertyTag propertyTag = new PropertyTag();
        propertyTag.setPropertyId(property.getPropertyId());
        propertyTag = cfgGigaSpace.read(propertyTag);
        if (propertyTag == null) {
            log.error("No propertyTag defined for propertyId {}", property.getPropertyId());
            return;
        }
        
        log.debug("Updating property [{}]", property);
        
        property.setPropertyTag(propertyTag);
        
        updatePropertyMap(propertyIdToPropertiesMap, property, property.getPropertyId());
        updatePropertyMap(filterIdToPropertiesMap, property, property.getFilterId());
    }
    
    public void removePropertyMapEntry(Property property) {
    	log.debug("removing property [{}]", property);
    	removePropertyMapEntry(propertyIdToPropertiesMap, property, property.getPropertyId());
    	removePropertyMapEntry(filterIdToPropertiesMap, property, property.getFilterId());
    }
    
    ////////////////////////////////////////////////////////////////
    // APIs for creating and removing entries from config tables. //
    ////////////////////////////////////////////////////////////////
    
	@Override
    public void createFilterTag(String filterTag, BigDecimal precedence, String derivation, String comment) 
            throws DuplicateTagException, NoSuchMethodException, InvalidDerivationException {
    	
    	// validate unique filterTag
    	if (filterTagMap.containsKey(filterTag)) {
    		throw new DuplicateTagException("filterTag " + filterTag);
    	}
    	
    	// validate unique precedence
    	FilterTag template = new FilterTag();
    	template.setPrecedence(precedence);
    	FilterTag t = cfgGigaSpace.read(template);
    	if (t != null) { 
    		throw new DuplicateTagException("precedence");
    	}
    	
		FilterTag tag = new FilterTag(idgFilterTag.generateId(), filterTag, precedence, derivation, comment);

		cfgGigaSpace.write(tag);
		
		addFilterTag(tag);
    }
    
	@Override
    public FilterTag removeFilterTag(String filterTag) {
    	FilterTag template = new FilterTag();
    	template.setFilterTag(filterTag);
    	
    	FilterTag tag = cfgGigaSpace.take(template);
    	if (tag == null) {
    		log.warn("FilterTag {} doesn't exist", filterTag);
    	} else {
    	    filterTagMap.remove(tag.getFilterTag());
    		log.info("FilterTag {} removed successfully", filterTag);
    	}
    	
    	return tag;
    }
    
	@Override
    public PropertyTag createPropertyTag(String propertyId, int fixTag, String propertyName) throws DuplicateTagException {
    	
    	// validate unique propertyId
	    PropertyTag propertyTag = new PropertyTag();
    	propertyTag.setPropertyId(propertyId);
    	if (cfgGigaSpace.read(propertyTag) != null) {
    		throw new DuplicateTagException("propertyId " + propertyId);
    	}
    	
    	PropertyTag tag = new PropertyTag(fixTag, propertyId, propertyName);
    	cfgGigaSpace.write(tag);
    	return tag;
    }
    
	@Override
    public PropertyTag removePropertyTag(String propertyId) {
    	PropertyTag template = new PropertyTag();
    	template.setPropertyId(propertyId);
    	return cfgGigaSpace.take(template);
    }

	@Override
    public void createFilter(String filterId, String filterConditions, String description) throws DuplicateTagException {
    	
    	// validate unique filterTag
    	Filter template = new Filter();
    	template.setFilterId(filterId);
    	Filter ft = cfgGigaSpace.read(template);
    	if (ft != null) {
    		throw new DuplicateTagException("filterId " + filterId);
    	}

    	cfgGigaSpace.write(new Filter(idgFilter.generateId(), filterId, filterConditions, description));
    }

	@Override
    public Filter removeFilter(String filterId) {
    	Filter template = new Filter();
    	template.setFilterId(filterId);
        return cfgGigaSpace.take(template);
    }
    
	@Override
	public Property createProperty(String instance, String filterId, String propertyId, String propertyValue, Character override, String comment) throws UnknownTagException {
    	Filter filter = new Filter();
    	filter.setFilterId(filterId);
    	filter = cfgGigaSpace.read(filter);
    	if (filter == null) {
    		throw new UnknownTagException("Filter " + filterId);
    	}
    	
    	PropertyTag propertyTag = new PropertyTag();
    	propertyTag.setPropertyId(propertyId);
    	propertyTag = cfgGigaSpace.read(propertyTag);
    	if (propertyTag == null) {
    		throw new UnknownTagException("PropertyTag " + propertyId);
    	}

		Property property = new Property(idgProperty.generateId(), filterId, instance, propertyTag, propertyValue, comment);
		if (override!=null)
			property.setOverride(override);
		
		cfgGigaSpace.write(property);
		
		return property;
	}

	@Override
    public Property removeProperty(String instance, String filterId, String propertyId) {
    	
    	Property property = new Property();
    	property.setFilterId(filterId);
    	property.setPropertyId(propertyId);
		property = cfgGigaSpace.take(property);
		if (property == null) {
		    return null;
		}
		
    	return property;
    }
	
	@Override
    public Filter updateFilter(String filterId, String filterConditions, String description) {
    	Filter filter = new Filter();
    	filter.setFilterId(filterId);
    	filter = cfgGigaSpace.read(filter);
    	if (filter == null) {
    	    log.warn("filter {} not found", filterId);
    	    return null;
    	}
    	
		log.info("updating filter {} set conditions to {}", filterId, filterConditions);
		log.debug("original - {}", filter.toString());
		
		if (filterConditions != null) {
			filter.setConditions(filterConditions);
		}
		
		if (description != null) {
			filter.setDescription(description);
		}
		
		cfgGigaSpace.write(filter);
		log.debug("updated - {}", filter.toString());
		
    	return filter;
    }
	
	@Override
	public Property updateProperty(String filterId, String propertyId, String propertyValue, Character override, String comment) {
    	Property property = new Property();
    	property.setFilterId(filterId);
    	property.setPropertyId(propertyId);
    	property = cfgGigaSpace.read(property);
    	if (property == null) {
    	    log.warn("property {} not found", propertyId);
    	    return null;
    	}
    	
		log.info("updating property {} set value to {}", propertyId, propertyValue);
		log.debug("original - {}", property.toString());
		
		if (propertyValue != null) {
			property.setPropertyValue(propertyValue);
		}
		
		if (comment != null) {
			property.setComment(comment);
		}
		
		if (override!=null)
			property.setOverride(override);
		
		cfgGigaSpace.write(property);
		log.debug("updated - {}", property.toString());
		
    	return property;
	}


	// setter / getter
	
	public void setConfigurableClass(Class<? extends IConfigurable> configurableClass) 
	            throws UnConfigurableException{
		this.configurableClass = configurableClass;
	}
	
	public Class<? extends IConfigurable> getConfigurableClass() {
		return configurableClass;
	}

    public void setGigaSpace(GigaSpace gigaSpace) {
        this.cfgGigaSpace = gigaSpace;
    }

	public void setUsePropertyTagFixIfUndefined(Boolean usePropertyTagFixIfUndefined) {
		this.usePropertyTagFixIfUndefined = usePropertyTagFixIfUndefined;
	}

    public Map<String, List<Property>> getAllPropertiesMap() {
        return propertyIdToPropertiesMap;
    }
    
    public FilterTag getFilterTag(String filterTag) {
        return filterTagMap.get(filterTag);
    }

    public FilterTagDerivation getFilterTagDerivation(FilterTag filterTag) {
        return filterTagDerivations.get(filterTag);
    }

    public void addFilter(Filter filter) {
        try { 
            filter.initFilterConditions(this);
            filterIdToFilterMap.put(filter.getFilterId(), filter);
        } catch (Exception e) {
            log.error("Ignoring filter {}, invalid FilterConditions [{}] - {}", 
                    new Object[] {filter.getFilterId(), filter.getConditions(), e.getMessage()});
        }
    }
    
    public void addFilterTag(FilterTag tag) {
        
        Method method = filterTagMethods.get(tag.getFilterTag()); 
        if (method != null) {
            log.debug("Setting derivation method for {}", tag);
            filterTagDerivations.put(tag, new FilterTagDerivation(method));
        } else {
            log.debug("Processing derivation {}", tag.getDerivation());
            try {
                filterTagDerivations.put(tag, new FilterTagDerivation(configurableClass, tag.getDerivation()));
            } catch (InvalidDerivationException e) {
                if (configurableClass == ConfigurableObject.class) {
                    log.warn("Please ignore exception thrown while processing filterTag [{}]", e.getMessage());
                } else {
                    log.error("Exception thrown while processing filterTag [{}]", e.getMessage());
                }
                return;
            }
        }
        
        filterTagMap.put(tag.getFilterTag(), tag);
    }

    public int getFilterTagCount() {
        return filterTagMap.size();
    }

    public void removeFilterFromMap(String filterId) {
        log.debug("removing filter {}", filterId);
        filterIdToFilterMap.remove(filterId);
    }

    public Map<String, Filter> getFilterIdToFilterMap() {
        return filterIdToFilterMap;
    }

}

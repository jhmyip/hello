package com.daiwacm.dats.configManager;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceExclude;
import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceRouting;

@Entity
@Table(name="Property")
@SpaceClass
public class Property implements Comparable<Property> {

    private Integer id;
	private String instance;
	private String propertyId;
	private String filterId;
	private PropertyTag propertyTag;
	private String propertyValue;
	private Character override;
	private Date startTime;
	private Date endTime;
	private String updatedBy;
	private Date lastUpdated;
	private String comment;
	private char active;

    public Property() {
    	active = 'Y'; // default is active
    }

    public Property(Integer id, String filterId, String instance, PropertyTag propertyTag, String propertyValue, String comment) {
        this.id = id;
        this.instance = instance;
        this.propertyTag = propertyTag;
        this.propertyId = propertyTag.getPropertyId();
        this.propertyValue = propertyValue;
        this.comment = comment;

		updatedBy = "confmgr";
		lastUpdated = Calendar.getInstance().getTime();
        this.active = 'Y';
        
        this.filterId = filterId;
    }
    
    public Property(Integer id, String filterId, String instance, PropertyTag propertyTag, String propertyValue, String comment,
                    Character override, Date startTime, Date endTime) {
        this(id, filterId, instance, propertyTag, propertyValue, comment);
        this.override = override;
        this.startTime = startTime;
        this.endTime = endTime;
    }

	@Id
    @SpaceId(autoGenerate = false)
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getFilterId() {
		return filterId;
	}

	public void setFilterId(String filterId) {
		this.filterId = filterId;
	}
	
    public String getInstance() {
        return instance;
    }
    
    public void setInstance(String instance) {
        this.instance = instance;
    }
    
    public String getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}
	
	@SpaceExclude
	@Transient
    public PropertyTag getPropertyTag() {
        return propertyTag;
    }
    
    public void setPropertyTag(PropertyTag propertyTag) {
        this.propertyTag = propertyTag;
    	propertyId = propertyTag.getPropertyId();
    }
    
    public String getPropertyValue() {
        return propertyValue;
    }
    
    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }
    public Character getOverride() {
        return override;
    }
    
    public void setOverride(Character override) {
        this.override = override;
    }
    public Date getStartTime() {
        return startTime;
    }
    
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }
    public Date getEndTime() {
        return endTime;
    }
    
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
    public String getUpdatedBy() {
        return updatedBy;
    }
    
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    public Date getLastUpdated() {
        return lastUpdated;
    }
    
    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }

    @SpaceRouting
    public char getActive() {
        return this.active;
    }
    
    public void setActive(char active) {
        this.active = active;
    }

    @SpaceExclude
    @Transient
    public boolean isValid() {
        Date today = new Date();
		return (startTime == null || startTime.compareTo(today) <= 0) &&
		       (endTime == null   || endTime.compareTo(today) >= 0) &&
		       active == 'Y';
    }
    
    @SpaceExclude
    @Transient
    public boolean isOverrideProperty() {
    	// default is don't override
    	return override != null && (override == 'Y' || override == 'y');
    }
    
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Property [")
		  .append("id=").append(id)
		  .append(", filter=").append(filterId)
		  .append(", instance=").append(instance)
		  .append(", propertyValue=").append(propertyValue)
		  .append(", override=").append(override)
		  .append(", startTime=").append(startTime)
		  .append(", endTime=").append(endTime)
		  .append(", updatedBy=").append(updatedBy)
		  .append(", lastUpdated=").append(lastUpdated)
		  .append(", active=").append(active);
		
		if (propertyTag != null) {
			sb.append(", propertyId=").append(propertyTag.getPropertyId());
		}
		sb.append("]");
		
		return sb.toString();
	}
	
	@Override
	public int compareTo(Property property) {
		int result = propertyId.compareTo(property.getPropertyId());
		if (result != 0) {
			return result;
		}
		
		// Same property id
		// valid one higher priority
		if (isValid() && !property.isValid()) { 
			return 1;
		} else if (!isValid() && property.isValid()) { 
			return -1;
		}
		
		// both valid
		// override one higher priority
		if (isOverrideProperty() && !property.isOverrideProperty()) { 
			return 1;
		} else if (!isOverrideProperty() && property.isOverrideProperty()) { 
			return -1;
		}
		
		// both override
		// more recent start time higher priority
		if (startTime == null && property.getStartTime() != null) {
			return -1;
		} else if (startTime != null && property.getStartTime() == null) {
			return 1;
		} else if (startTime != null && property.getStartTime() != null) { 
			result = startTime.compareTo(property.getStartTime());
			if (result != 0) {
				return result;
			}
		}
		
		// same start time
		// more recent end time higher priority
		if (endTime == null && property.getEndTime() != null) {
			return -1;
		} else if (endTime != null && property.getEndTime() == null) {
			return 1;
		} else if (endTime != null && property.getEndTime() != null) { 
			return property.getEndTime().compareTo(endTime);
		}

		return 0;
	}
}
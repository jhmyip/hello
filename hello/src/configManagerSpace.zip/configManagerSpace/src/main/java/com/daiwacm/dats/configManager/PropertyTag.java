package com.daiwacm.dats.configManager;


import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;


@Entity
@Table(name="PropertyTag")
@SpaceClass
public class PropertyTag {
    
    private Integer fixTag;
    private String propertyId;
    private String name;
    private String updatedBy;
    private Date lastUpdated;
     
    public PropertyTag() {
    }

    public PropertyTag(Integer fixTag, String propertyId, String name) {
		this.fixTag = fixTag;
		this.propertyId = propertyId;
		this.name = name;
		updatedBy = "confmgr";
		lastUpdated = Calendar.getInstance().getTime();
	}

	@Id 
    @SpaceId(autoGenerate = false)
	public String getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(String mnemonic) {
		this.propertyId = mnemonic;
	}

    public Integer getFixTag() {
		return fixTag;
	}

	public void setFixTag(Integer tag) {
		this.fixTag = tag;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

    public String getUpdatedBy() {
        return this.updatedBy;
    }
    
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    public Date getLastUpdated() {
        return this.lastUpdated;
    }
    
    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

	@Override
	public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("PropertyTag [")
	      .append("fixTag=").append(fixTag)
	      .append(", propertyId=").append(propertyId)
		  .append(", name=").append(name)
		  .append(", updatedBy=").append(updatedBy)
		  .append(", lastUpdated=").append(lastUpdated) //+ ", algoMatrix # =" + algoMatrix.size()
		  .append("]");
	    return sb.toString();
	}

}
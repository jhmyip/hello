package com.daiwacm.dats.configManager.common;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daiwacm.dats.configManager.FilterTag;
import com.daiwacm.dats.configManager.FilterTagDerivation;

public abstract class Condition implements Comparable<Condition> {
    
    private static final Logger log = LoggerFactory.getLogger(Condition.class);
    
    public enum ConditionOperator {
        // <> <= >= must be positioned before = > < or the condition string will be parsed incorrectly.
        NE ("<>") {
                @Override public boolean eval(String k, String v)       { return ! k.equals(v); } 
                @Override public boolean eval(BigDecimal k, BigDecimal v) { return k.compareTo(v)!=0; } // not use BigDecimal.equals as it considers scale as well.
                @Override public Integer precedence() { return 1; }
            },
        LE ("<=") {
                @Override public boolean eval(String k, String v)       { return k.compareTo(v)<=0; } 
                @Override public boolean eval(BigDecimal k, BigDecimal v) { return k.compareTo(v)<=0; } 
                @Override public Integer precedence() { return 3; }
            },
        GE (">=") {
                @Override public boolean eval(String k, String v)       { return k.compareTo(v)>=0; } 
                @Override public boolean eval(BigDecimal k, BigDecimal v) { return k.compareTo(v)>=0; } 
                @Override public Integer precedence() { return 3; }
            },
        EQ ("=")  {   
                @Override public boolean eval(String k, String v)       { return k.equals(v); } 
                @Override public boolean eval(BigDecimal k, BigDecimal v) { return k.compareTo(v)==0; } // not use BigDecimal.equals as it considers scale as well. 
                @Override public Integer precedence() { return 4; }
            },  
        LT ("<")  {   
                @Override public boolean eval(String k, String v)       { return k.compareTo(v)<0; } 
                @Override public boolean eval(BigDecimal k, BigDecimal v) { return k.compareTo(v)<0; } 
                @Override public Integer precedence() { return 2; }
            },
        GT (">")  {
                @Override public boolean eval(String k, String v)       { return k.compareTo(v)>0; } 
                @Override public boolean eval(BigDecimal k, BigDecimal v) { return k.compareTo(v)>0; } 
                @Override public Integer precedence() { return 2; }
            },
        LIKE (" like ") { // format "%ABC%"
                @Override public boolean eval(String k, Pattern v)      { return v.matcher(k).find(); }
            },
        IN (" in ") { 
                @Override public boolean eval(String k, Set<String> v)  { return v.contains(k); }
            };
        
        private String operator;
        public static ConditionOperator[] values = values();
        
        ConditionOperator(String operator) {
            this.operator = operator;
        }
        
        public boolean eval(String k, String v) { return false; }
        public boolean eval(BigDecimal k, BigDecimal v) { return false; }
        public boolean eval(String k, Pattern v) { return false; }
        public boolean eval(String k, Set<String> v) { return false; }
        public Integer precedence() { return 0; }

        @Override
        public String toString() { return operator; }

        public String getOperator() {
            return operator;
        }
    }
    
    private Condition(FilterTag tag, FilterTagDerivation filterTagDerivation, ConditionOperator op) {
        this.tag = tag;
        this.filterTagDerivation = filterTagDerivation;
        this.op = op;
    }
    
    protected FilterTagDerivation filterTagDerivation;
    protected FilterTag tag;
    protected ConditionOperator op;
    
    public FilterTag getTag() {
		return tag;
	}

	public ConditionOperator getOp() {
		return op;
	}

	@Override
	public int compareTo(Condition o) {
		// compare FilterTag first then operator
    	int compareFilterTag = tag.compareTo(o.tag);
    	if (compareFilterTag!=0)
    		return compareFilterTag;
    	else
    		return op.precedence().compareTo(o.op.precedence());
	}

	public boolean eval(IConfigurable configurable, boolean wildcard) {
        Object operand = filterTagDerivation.derive(configurable);
        if (operand == null)
            return wildcard;
        else
        	return protectedEval(operand, wildcard);
    }
    
    protected abstract boolean protectedEval(Object operand, boolean wildcard);
    
    private static class StringCondition extends Condition {
        private String value;
        protected StringCondition(FilterTag tag, FilterTagDerivation filterTagDerivation, 
                                  ConditionOperator op, String value) {
            super(tag, filterTagDerivation, op);
            this.value = value;
        }

        @Override
        protected boolean protectedEval(Object operand, boolean wildcard) {
            return op.eval(operand.toString(), value);
        }

        @Override
        public String toString() {
            return tag + " " + op.name() + " " + value;
        }
    }
    
    private static class NumberCondition extends Condition {
        private BigDecimal value;
        protected NumberCondition(FilterTag tag, FilterTagDerivation filterTagDerivation, 
                                  ConditionOperator op, String value) {
            super(tag, filterTagDerivation, op);
            this.value = new BigDecimal(value);
        }
        
        @Override
        protected boolean protectedEval(Object operand, boolean wildcard) {
           try {
                return op.eval(new BigDecimal(operand.toString()), value);
            } catch (NumberFormatException e) {
                log.error("NumberFormatException: {} {}", operand, e.getMessage());
                return false;
            }
        }
        
        @Override
        public String toString() {
            return tag + " " + op.name() + " " + value;
        }
    }
    
    private static class PatternCondition extends Condition {
        private Pattern value;
        protected PatternCondition(FilterTag tag, FilterTagDerivation filterTagDerivation,
                                   ConditionOperator op, String value) {
            // val can be either a regular expression or SQL wild card. 
            // replace the sql wild card char "%" to ".*"
            super(tag, filterTagDerivation, op);
            String regex = value.replaceAll("%", "\\.\\*");
            log.debug("translate {} to {}", value, regex);
            this.value = Pattern.compile(regex);
        }
        
        @Override
        protected boolean protectedEval(Object operand, boolean wildcard) {
            return op.eval(operand.toString(), value);
        }
        
        @Override
        public String toString() {
            return tag + " " + op.name() + " " + value;
        }
    }
    
    private static class SetCondition extends Condition {
        private static Pattern pattern = Pattern.compile("\\((.*)\\)");
        private Set<String> value;
        protected SetCondition(FilterTag tag, FilterTagDerivation filterTagDerivation,
                               ConditionOperator op, String value) {
            super(tag, filterTagDerivation, op);
            Matcher matcher = pattern.matcher(value); 
            if (matcher.find()) {
                this.value = new HashSet<String>(Arrays.asList(matcher.group(1).split(", *")));
            } else {
                log.error("operand in wrong format for IN {}", value);
                // try to split..
                this.value = new HashSet<String>(Arrays.asList(value.split(", *")));
            }
        }
        
        @Override
        protected boolean protectedEval(Object operand, boolean wildcard) {
            return op.eval(operand.toString(), value);
        }
        
        @Override
        public String toString() {
            return tag + " " + op.name() + " " + value;
        }
    }
    
    public static Condition create(FilterTag tag, FilterTagDerivation filterTagDerivation, ConditionOperator op, 
                                   String value) {
        Class<?> tagType = filterTagDerivation.getFilterTagType();
        switch (op) {
    	case LIKE :
            return new PatternCondition(tag, filterTagDerivation, op, value);
    	case IN :
            return new SetCondition(tag, filterTagDerivation, op, value);
        default :
	        if (tagType.equals(String.class) || tagType.isEnum()) {
	            return new StringCondition(tag, filterTagDerivation, op, value);
	        } else if (value.matches("[0-9\\.]*")) {
	            return new NumberCondition(tag, filterTagDerivation, op, value);
	        } else {
	            log.warn("Convert unsupported type {} to String ", tagType);
	            return new StringCondition(tag, filterTagDerivation, op, value);
	        }
        }
    }
}
package com.daiwacm.dats.configManager.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daiwacm.dats.refdata.model.interfaces.Product;

public class ConfigurableObject implements IConfigurable {

	private static final Logger log = LoggerFactory.getLogger(ConfigurableObject.class);


	@Override
	public Product getProduct() { return null; }

	String exch;
	@ConfigurableTag
	public String getExchange() { return exch; }

	public void setExchange(String exch) {
		log.info("setting ConfigurableObject.exch {}", exch);
		this.exch = exch;
	}

	@Override
	public String getField(int field) {
		return null;
	}

	@Override
	public void setField(int field, String value) {
	
	}

}

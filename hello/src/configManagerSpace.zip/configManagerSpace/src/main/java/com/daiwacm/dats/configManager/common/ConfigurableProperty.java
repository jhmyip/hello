package com.daiwacm.dats.configManager.common;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declare the method for setting the property value. 
 */
@Documented
@Retention(value = RetentionPolicy.RUNTIME)
@Target(value = ElementType.METHOD)
public @interface ConfigurableProperty {
	/**
	 * @return Property name
	 */
	String propertyName() default "";
}

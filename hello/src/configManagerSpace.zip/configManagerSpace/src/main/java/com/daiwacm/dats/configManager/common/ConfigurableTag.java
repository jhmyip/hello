package com.daiwacm.dats.configManager.common;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Overrides the derivation setting of the FilterTag by this annotated method.
 * 
 *  if tagName is not specified, obtain the tag from getter
 */
@Documented
@Retention(value = RetentionPolicy.RUNTIME)
@Target(value = ElementType.METHOD)
public @interface ConfigurableTag {
	/**
	 * @return FilterTag name
	 */
	String tagName() default "";
}

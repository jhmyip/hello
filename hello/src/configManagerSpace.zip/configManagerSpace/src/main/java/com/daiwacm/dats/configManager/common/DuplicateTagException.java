package com.daiwacm.dats.configManager.common;

public class DuplicateTagException extends Exception {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    String err;
	public DuplicateTagException() {}
	public DuplicateTagException(String msg) { 
		super("Duplcated Tag: " + msg);
		err = "Duplcated Tag: " + msg;
	}
	@Override
	public String getMessage() {
		return err;
	}
}


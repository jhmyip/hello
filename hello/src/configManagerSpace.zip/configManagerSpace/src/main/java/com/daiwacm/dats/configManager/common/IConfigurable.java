package com.daiwacm.dats.configManager.common;

import com.daiwacm.dats.refdata.model.interfaces.Product;


/**
 * indicates configurable by the configManager
 *
 */
public interface IConfigurable {
	Product getProduct();
	String getField(int field);
	void setField(int field, String value);
}

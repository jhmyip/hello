package com.daiwacm.dats.configManager.common;

public class InvalidConditionException extends Exception {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    String err;
	public InvalidConditionException() {}
	public InvalidConditionException(String msg) { 
		super("Invalid condition format: " + msg);
		err = "Invalid condition format: " + msg;
	}
	@Override
	public String getMessage() {
		return err;
	}
}

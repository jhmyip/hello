package com.daiwacm.dats.configManager.common;

public class InvalidDerivationException extends Exception {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
	public InvalidDerivationException(String derivation) { 
		super("Ignoring invalid derivation: " + derivation);
	}
}

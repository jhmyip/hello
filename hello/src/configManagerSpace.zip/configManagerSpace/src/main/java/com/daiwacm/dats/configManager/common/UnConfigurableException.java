package com.daiwacm.dats.configManager.common;

public class UnConfigurableException extends Exception {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    String err;
	public UnConfigurableException() {}
	public UnConfigurableException(String msg) { 
		super("UnConfigurable class " + msg);
		err = "UnConfigurable class " + msg;
	}
	@Override
	public String getMessage() {
		return err;
	}
}

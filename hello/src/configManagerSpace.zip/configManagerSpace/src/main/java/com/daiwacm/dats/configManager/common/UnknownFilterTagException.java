package com.daiwacm.dats.configManager.common;

public class UnknownFilterTagException extends Exception {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    String err;
	public UnknownFilterTagException() {}
	public UnknownFilterTagException(String msg) { 
		super("unknown FilterTag in condition: " + msg);
		err = "unknown FilterTag in condition: " + msg;
	}
	@Override
	public String getMessage() {
		return err;
	}
}

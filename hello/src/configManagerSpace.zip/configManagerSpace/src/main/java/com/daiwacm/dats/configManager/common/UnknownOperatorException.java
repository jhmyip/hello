package com.daiwacm.dats.configManager.common;

public class UnknownOperatorException extends Exception {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    String err;
	public UnknownOperatorException() {}
	public UnknownOperatorException(String msg) {
		super("unknown operator in condition: " +  msg); 
		err = "unknown operator in condition: " +  msg;
	}
	@Override
	public String getMessage() {
		return err;
	}
}
package com.daiwacm.dats.configManager.common;

public class UnknownTagException extends Exception {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    String err;
	public UnknownTagException() {}
	public UnknownTagException(String msg) { 
		super("Unknown Tag: " + msg);
		err = "Unknown Tag: " + msg;
	}
	@Override
	public String getMessage() {
		return err;
	}
}

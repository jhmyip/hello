package com.daiwacm.dats.configManager.event;

import org.openspaces.core.GigaSpace;
import org.openspaces.events.EventDriven;
import org.openspaces.events.EventTemplate;
import org.openspaces.events.adapter.SpaceDataEvent;
import org.openspaces.events.notify.Notify;
import org.openspaces.events.notify.NotifyType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.daiwacm.dats.configManager.MainConfigManager;
import com.daiwacm.dats.configManager.FilterTag;

@EventDriven
@Notify(gigaSpace="cfgGigaSpace")
@NotifyType(update=true, write=true, take=true)
public class FilterTagUpdateNotifier {
    private static Logger log = LoggerFactory.getLogger(FilterTagUpdateNotifier.class);
    
    @Autowired
    private MainConfigManager configManager;

	@EventTemplate
	public FilterTag baseTemplate() {
		return new FilterTag();
	}

	@SpaceDataEvent
	public void eventListener(FilterTag event, GigaSpace gigaSpace) {
		FilterTag f = gigaSpace.readIfExistsById(FilterTag.class, event.getId());
		
		if (f!=null) {
			log.info("Received FilterTag update event: {}", event);
			configManager.addFilterTag(event);
		} else {
		    log.info("Realtime update for FilterTag removal ignored atm: {} {}.", event.getId(), event.getFilterTag());
		}
	}
}

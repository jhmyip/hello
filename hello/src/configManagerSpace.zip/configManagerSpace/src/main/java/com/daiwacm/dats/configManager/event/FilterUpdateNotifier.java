package com.daiwacm.dats.configManager.event;

import org.openspaces.core.GigaSpace;
import org.openspaces.events.EventDriven;
import org.openspaces.events.EventTemplate;
import org.openspaces.events.adapter.SpaceDataEvent;
import org.openspaces.events.notify.Notify;
import org.openspaces.events.notify.NotifyType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.daiwacm.dats.configManager.MainConfigManager;
import com.daiwacm.dats.configManager.Filter;

@EventDriven
@Notify(gigaSpace="cfgGigaSpace")
@NotifyType(update=true, write=true, take=true)
public class FilterUpdateNotifier {
    private static Logger log = LoggerFactory.getLogger(FilterUpdateNotifier.class);
    
    @Autowired
    private MainConfigManager configManager;

	@EventTemplate
	public Filter baseTemplate() {
		return new Filter();
	}

	@SpaceDataEvent
	public void eventListener(Filter event, GigaSpace gigaSpace) {
		Filter f = gigaSpace.readIfExistsById(Filter.class, event.getId());
		
		if (f!=null) {
			log.info("Received Filter update event: id {}", event.getId());
	    	log.debug("updating filter [{}]", event);
			configManager.addFilter(event);
		} else {
			log.info("Received Filter take event: id {}", event.getId());
			configManager.removeFilterFromMap(event.getFilterId());
		}
	}
}

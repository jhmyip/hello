package com.daiwacm.dats.configManager.event;

import org.openspaces.core.GigaSpace;
import org.openspaces.events.EventDriven;
import org.openspaces.events.EventTemplate;
import org.openspaces.events.adapter.SpaceDataEvent;
import org.openspaces.events.notify.Notify;
import org.openspaces.events.notify.NotifyType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.daiwacm.dats.configManager.MainConfigManager;
import com.daiwacm.dats.configManager.Property;

@EventDriven
@Notify(gigaSpace="cfgGigaSpace")
@NotifyType(update=true, write=true, take=true)
public class PropertyUpdateNotifier {
    private static Logger log = LoggerFactory.getLogger(PropertyUpdateNotifier.class);
    
    @Autowired
    private MainConfigManager configManager;

	@EventTemplate
	public Property baseTemplate() {
		return new Property();
	}

	@SpaceDataEvent
	public void eventListener(Property event, GigaSpace gigaSpace) {
		if (gigaSpace.readIfExistsById(Property.class, event.getId()) != null) {
			log.info("Received Property update event: id {}", event.getId());
			configManager.updateProperty(event);
		} else {
			log.info("Received Property take event: id {}", event.getId());
			configManager.removePropertyMapEntry(event);
		}
	}
}

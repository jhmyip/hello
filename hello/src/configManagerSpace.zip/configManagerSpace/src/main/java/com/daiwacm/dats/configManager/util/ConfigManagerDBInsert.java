package com.daiwacm.dats.configManager.util;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 * Currently this program generates insert statements from xml file cfgMgrTestData.xml
 * TODO: insert to DB directly. 
 */
public class ConfigManagerDBInsert {
    
	public static void main(String argv[]) {
		String path;
		if (argv.length > 1) {
			path = argv[0];
		} else {
			path = System.getProperty("user.dir") + "\\src\\main\\resources\\META-INF\\spring\\cfgMgrTestData.xml";
		}
		System.out.println("Path " + path);
		
		Document doc = null;
		try {
			File file = new File(path);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			doc = db.parse(file);
			doc.getDocumentElement().normalize();
		} catch (Exception e) {
		    e.printStackTrace();
		}
		  
		NodeList nodeLst = doc.getElementsByTagName("bean");
		  
		System.out.println("Number of beans " + nodeLst.getLength());
		  
		for (int s = 0; s < nodeLst.getLength(); s++) {
	
		    Node fstNode = nodeLst.item(s);
		    
	    	Element fstElmnt = (Element) fstNode;

	    	String attr = fstElmnt.getAttribute("id");
	    	System.out.println(">> " + attr);
	    	
	    	if (attr == null || ! attr.equals("cfgTestInitializer")) continue;
	    	
	    	NodeList ppts = fstElmnt.getElementsByTagName("property");
	    	
	    	System.out.println(">>> " + ppts.getLength());

	    	for (int p=0; p < ppts.getLength(); p++) {
	    		Element ppt = (Element)ppts.item(p);
	    		
	    		processProperty(ppt);
	    	}
		}
	}
	
	static void processProperty(Element ppt) {
		String pptName = ppt.getAttribute("name");
		
		System.out.print("::: " + pptName);
		
		if (pptName.equals("gigaSpace")) {
			System.out.println("\tskip");
			return;
		}
		NodeList mapLst = ppt.getElementsByTagName("map");
		System.out.println("\t" + mapLst.getLength());

		for (int m=0; m<mapLst.getLength(); m++) {
			Element map = (Element)mapLst.item(m);
			NodeList entries = map.getElementsByTagName("entry");
			
			Map<String, String> keyValueMap = new HashMap<String, String>();
			
			int entryId = m+1;
			
			for (int e=0; e < entries.getLength(); e++) {
				Element entry = (Element) entries.item(e);
				String key = entry.getAttribute("key");
				String value = entry.getAttribute("value");
				keyValueMap.put(key, value);
			}

			if (pptName.equals("filterTags")) {
				String filterTag = keyValueMap.get("name");
				String precedence = keyValueMap.get("precedence");
				String derivation = keyValueMap.get("derivation");
				
				System.out.println("insert into FilterTag " +
						"(id,filterTag,precedence,derivation,updatedBy,lastUpdated,comment,active) values " +
						"(" + entryId + ", '" + filterTag + "', " + precedence + ", '" + derivation + "', user_name(), getdate(), '', 'Y')");
				
    		} else if (pptName.equals("filters")) {
    			String filterId = keyValueMap.get("name");
    			String conditions = keyValueMap.get("condition");
				
				System.out.println("insert into Filter (id,filterId,conditions,description,updatedBy,lastUpdated,active) values " +
						"(" + entryId + ", '" + filterId + "', '" + conditions + "', '', user_name(), getdate(), 'Y')");
				
    		} else if (pptName.equals("propertyTags")) {
    			String propertyId = keyValueMap.get("id");
    			String fixTag = keyValueMap.get("tag");

				System.out.println("insert into PropertyTag (propertyId,fixTag,name,updatedBy,lastUpdated) values " +
						"('" + propertyId + "', " + fixTag + ", '', user_name(), getdate())");

    		} else if (pptName.equals("properties")) {
    			String filterId = keyValueMap.get("filterName");
    			String propertyId = keyValueMap.get("id");
    			String propertyValue = keyValueMap.get("value");
				System.out.println("insert into Property (id,instance,filterId,propertyId,propertyValue,override,startTime,endTime,updatedBy,lastUpdated,comment,active) values " +
						"(" + entryId + ", '*', '" + filterId + "', '" + propertyId + "', '" + propertyValue + "', null, null, null, user_name(), getdate(), '', 'Y')");

    		}
		}
	}
}

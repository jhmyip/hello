package com.daiwacm.dats.configManager.util;


import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

import org.openspaces.core.GigaSpace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.daiwacm.dats.configManager.Filter;
import com.daiwacm.dats.configManager.FilterTag;
import com.daiwacm.dats.configManager.ConfigManager;
import com.daiwacm.dats.configManager.Property;
import com.daiwacm.dats.configManager.PropertyTag;
import com.j_spaces.core.client.SQLQuery;

public class ConfigPublisher {
	
    private static final Logger log = LoggerFactory.getLogger(ConfigPublisher.class);
    
    @Autowired
    private GigaSpace cfgGigaSpace;
    
    @Autowired
    private ConfigManager configManager;
    
    public void printUsageAndExit() {
    	System.out.println(">> Usage " + ConfigPublisher.class);
    	System.out.println("\t COMMAND LINE INSTRUCTIONS");
    	System.out.println("\t list filter");
    	System.out.println("\t list property");
    	System.out.println("\t list property condition 'conditions'");
    	System.out.println("\t list property filter 'filterId'");
    	System.out.println("\t list filterTag");
    	System.out.println("\t list propertyTag");
    	System.out.println("\t add filter 'filterId' 'conditions' 'comment'");
    	System.out.println("\t add property 'filterId' 'propertyId' 'value' 'comment'");
    	System.out.println("\t add property 'filterId' 'propertyId' 'value' override 'comment'");
    	System.out.println("\t add filterTag 'filterTag' 'precedence' 'derivation' 'comment'");
    	System.out.println("\t add propertyTag 'propertyId' 'fixTag' 'comment'");
    	System.out.println("\t update filter 'filterId' 'conditions' comment");
    	System.out.println("\t update property 'filterId' propertyId 'value' override [comment]");
    	System.out.println("\t delete filter 'filterId'");
    	System.out.println("\t delete property 'filterId' 'propertyId'");
    	System.out.println("\t delete filterTag 'filterTag'");
    	System.out.println("\t delete propertyTag 'propertyId'");
    	System.out.println("");
    	System.out.println("\t where override is Y or y or N or n");
    	System.exit(1);
    }

    private int nextArgIndex = 0;
    private String[] myArgs;
    private String getNext() {
        if (nextArgIndex == myArgs.length) {
            printUsageAndExit();
        }
        
        return myArgs[nextArgIndex++];
    }
    
    private String getNextOptional() {
        if (nextArgIndex == myArgs.length) {
            return null;
        }
        
        return myArgs[nextArgIndex++];
    }
    
    public static void main(String[] args) throws Exception {
    	Map<String, String> map = System.getenv();
    	log.debug("LOOKUPLOCATORS: {}", map.get("LOOKUPLOCATORS"));
    	log.debug("LOOKUPGROUPS: {}", map.get("LOOKUPGROUPS"));
    	
        // update env variables LOOKUPLOCATORS & LOOKUPGROUPS to refer to different space
        // -Dcom.gs.jini_lus.groups=LOOKUPGROUPS -Dcom.gs.jini_lus.locators=LOOKUPLOCATORS
        ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("classpath*:/META-INF/spring/configPublisher.xml");
        ConfigPublisher publisher = (ConfigPublisher) context.getBean("configPublisher");
        
        publisher.run(args);
    }
    
    private enum Command {
        list, add, update, delete,
    }
    
    private enum CommandType {
        filter, property, filterTag, propertyTag,
    }
    
    public void run(String[] args) throws Exception {
        myArgs = args;
		
		Command command = null;
		CommandType commandType = null;
		try {
		    command = Command.valueOf(getNext());
		    commandType = CommandType.valueOf(getNext());
		} catch (Exception e) {
		    printUsageAndExit();
		}

		switch (command) {
		case list:
		    switch (commandType) {
		    case filter: list(Filter.class, " order by id"); break;
		    case property: readFilterProperty(getNextOptional(), getNextOptional()); break;
		    case filterTag: list(FilterTag.class, " order by precedence"); break;
		    case propertyTag: list(PropertyTag.class, " order by fixTag"); break;
		    } 
		    break;
		case add:
		    switch (commandType) {
		    case filter: configManager.createFilter(getNext(), getNext(), getNext()); break;
		    case property:
		    	String filterId = getNext();
		    	String propertyId = getNext();
		    	String propertyValue = getNext();
		    	String arg4 = getNext(); // override
		    	String arg5 = getNextOptional();
		    	if (arg5==null) {
		    		configManager.createProperty("*", filterId, propertyId, propertyValue, null, arg4);
		    	} else if (arg4.matches("^[YyNn]$")) {
		    		configManager.createProperty("*", filterId, propertyId, propertyValue, arg4.charAt(0), arg5);
		    	} else {
		    		printUsageAndExit();
		    	}
		    	break;
		    case filterTag: configManager.createFilterTag(getNext(), new BigDecimal(getNext()), getNext(), getNext()); break;
		    case propertyTag: configManager.createPropertyTag(getNext(), Integer.parseInt(getNext()), getNext()); break;
		    } 
		    break;
        case update: 
            switch (commandType) {
            case filter: configManager.updateFilter(getNext(), getNext(), getNextOptional()); break;
            case property: 
                String filterId = getNext();
                String propertyId = getNext();
                String propertyValue = getNext();
                String arg4 = getNext();
                String comment = getNextOptional();
                Character override = null;
                if (arg4!=null && arg4.matches("^[YyNn]$")) {
                    override = arg4.charAt(0);
                }
                configManager.updateProperty(filterId, propertyId, propertyValue, override, comment);
                break;
            default: printUsageAndExit(); break;
            } 
            break;
		case delete:
		    int exitCode = 0;
		    switch (commandType) {
		    case filter: exitCode = configManager.removeFilter(getNext()) == null ? 1 : 0; break;
		    case property: exitCode = configManager.removeProperty("*", getNext(), getNext()) == null ? 1 : 0; break;
		    case filterTag: exitCode = configManager.removeFilterTag(getNext()) == null ? 1 : 0; break;
		    case propertyTag: exitCode = configManager.removePropertyTag(getNext()) == null ? 1 : 0; break;
		    }
		    System.exit(exitCode);
		}
    }

    public <T> void list(Class<T> clazz, String query) {
        for (T t : cfgGigaSpace.readMultiple(new SQLQuery<T>(clazz, query), Integer.MAX_VALUE)) {
            log.debug(t.toString());
            System.out.println(t);
        }
    }    
    
    public void readFilterProperty(String type, String arg2) {
    	
        Map<String, Integer> fixTag = new HashMap<String, Integer>();
        SQLQuery<PropertyTag> query = new SQLQuery<PropertyTag>(PropertyTag.class, " order by fixTag");
        for (PropertyTag propertyTag : cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE)) {
            fixTag.put(propertyTag.getPropertyId(), propertyTag.getFixTag());
        }
        
        String conditions;
        if ("condition".equals(type)) {
            conditions = " conditions like '%"+ arg2 +"%'";
        } else if ("filter".equals(type)) {
            conditions = " filterId like '%"+ arg2 +"%'";
        } else {
            conditions = "";
        }
        
    	Filter[] fs = cfgGigaSpace.readMultiple(new SQLQuery<Filter>(Filter.class, conditions + " order by id"), Integer.MAX_VALUE);
    	
    	if (fs.length==0) {
    		System.out.println("No Filter Record Found.");
    		log.debug("No Filter found for conditions [{}]", conditions);
    		return;
    	}
    	
    	for (Filter f : fs) {
    		System.out.println("\n\n-----------------------------------------------------------------------------------------------------------");
    		System.out.format("%-40s%-50s%-10s", "[Filter Id]", "[Conditions]", "[Active]");
    		System.out.format("\n%-40s%-50s%-10s", f.getFilterId(), f.getConditions(), f.getActive());

	    	System.out.format("\n\n%-40s%-15s%-40s" , "[PropertyId]", "[FixTag]", "[Value]");
	    	
	    	Property pt = new Property();
            pt.setFilterId(f.getFilterId());
	    	
	    	// sorted by property id
    		for (Property p : new TreeSet<Property>(Arrays.asList(cfgGigaSpace.readMultiple(pt, Integer.MAX_VALUE)))) {
	    		System.out.format("\n%-40s%-15s%-40s" ,p.getPropertyId(), fixTag.get(p.getPropertyId()), p.getPropertyValue());
	    		log.info("{}\tFilterId={}\tConditions={}\tActive={};\t{}\tPropertyId={}\tFixTag={}\tValue={}", 
    				new Object[] {f.getId(), f.getFilterId(), f.getConditions(), f.getActive(), 
						p.getId(), p.getPropertyId(), fixTag.get(p.getPropertyId()), p.getPropertyValue()});
	    	}
    	}
    } 
}

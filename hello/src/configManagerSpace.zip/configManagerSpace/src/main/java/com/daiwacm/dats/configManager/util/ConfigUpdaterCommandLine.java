package com.daiwacm.dats.configManager.util;


import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.StringUtils;
import org.openspaces.core.GigaSpace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import au.com.bytecode.opencsv.CSVParser;
import au.com.bytecode.opencsv.CSVReader;

import com.daiwacm.dats.common.Number;
import com.daiwacm.dats.configManager.Filter;
import com.daiwacm.dats.configManager.FilterTag;
import com.daiwacm.dats.configManager.ConfigManager;
import com.daiwacm.dats.configManager.Property;
import com.daiwacm.dats.configManager.PropertyTag;
import com.daiwacm.dats.refdata.editor.RdEditorCommandLine;
import com.j_spaces.core.client.SQLQuery;

public class ConfigUpdaterCommandLine {

    private static final Logger log = LoggerFactory.getLogger(ConfigUpdaterCommandLine.class);

    private static Map<String, Integer> fixTag = new HashMap<String, Integer>();

    @Autowired
    @Qualifier("cfgGigaSpace")
    private GigaSpace cfgGigaSpace;

    @Autowired
    private ConfigManager configManager;

    private static ClassPathXmlApplicationContext CONTEXT;

    public static ConfigUpdaterCommandLine getConfigUpdater() {
        // update env variables LOOKUPLOCATORS & LOOKUPGROUPS to refer to different space
        // -Dcom.gs.jini_lus.groups=LOOKUPGROUPS -Dcom.gs.jini_lus.locators=LOOKUPLOCATORS
        return (ConfigUpdaterCommandLine) getContext().getBean("configPublisher");
    }

    public static void usage() {
        System.out.println(">> Usage " + ConfigUpdaterCommandLine.class);
        System.out.println("\t COMMAND LINE INSTRUCTIONS");
        System.out.println("\t account csvFile ");
        System.out.println("\t customer csvFile ");
    }

    public static void main(String[] args) throws Exception {
        try {
        	getConfigUpdater().updateCustomerSetup(args);
        } catch (Exception e) {
        	System.exit(1);
        }
        System.exit(0);
    }

    public void updateCustomerSetup(String[] args) throws Exception {

        if (args.length<=1) {
            usage();
            System.exit(1);
        }

        getFixTagMapping(fixTag);
        final String csvFilePath = args[1];
        List<String[]> csvData = getCsvContents(csvFilePath);

        try {
            // Processing the account file CSV data
            if ("account".equalsIgnoreCase(args[0])) {
                processAccountCsvData(csvData);
            } else if ("customer".equalsIgnoreCase(args[0])) {
                // Processing the customer file CSV data
                processCustomerCsvData(csvData);
            } else {
                System.out.println("Invalid identifier : " + args[0]);
                usage();
            }
            if (args.length==3) { 
                RdEditorCommandLine.edit("Edit", args[2], CONTEXT);
            }
        } catch (Exception e) {
        	  throw e;
        }
    }

    public void getFixTagMapping(Map<String, Integer> fixTag) {
        SQLQuery<PropertyTag> query = new SQLQuery<PropertyTag>(PropertyTag.class, " order by fixTag");
        PropertyTag[] pt = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);

        for (PropertyTag propertyTag : pt) {
            fixTag.put(propertyTag.getPropertyId(), propertyTag.getFixTag());
        }
    }

    public void readFilter() {
        SQLQuery<Filter> query = new SQLQuery<Filter>(Filter.class, " order by id");
        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);

        for (Filter f : fs) {
            System.out.println(f);
        }
    }    

    public void readFilterTag() {
        SQLQuery<FilterTag> query = new SQLQuery<FilterTag>(FilterTag.class, " order by precedence");
        FilterTag[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);

        for (FilterTag t : fs) {
            System.out.println(t);
        }
    }    

    public void readPropertyTag() {
        SQLQuery<PropertyTag> query = new SQLQuery<PropertyTag>(PropertyTag.class, " order by fixTag");
        PropertyTag[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);

        for (PropertyTag t : fs) {
            System.out.println(t);
        }
    }    

    public void readFilterProperty(String conditions) {

        SQLQuery<Filter> query;
        Filter[] fs;

        if (conditions.equals("")) {
            query = new SQLQuery<Filter>(Filter.class, " order by id");
            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
        } else {
            query = new SQLQuery<Filter>(Filter.class, " conditions like '%"+ conditions +"%'" + " order by id");
            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);   
        }

        if(fs.length==0) {
            System.out.println("No Record Found.");
            return;
        }

        for (Filter f : fs) {
            System.out.println("\n\n-----------------------------------------------------------------------------------------------------------");
            System.out.format("%-40s%-50s%-10s", "[Filter Id]", "[Conditions]", "[Active]");
            System.out.format("\n%-40s%-50s%-10s", f.getFilterId(), f.getConditions(), f.getActive());
            Property pt = new Property();
            pt.setFilterId(f.getFilterId());

            Property[] ps = cfgGigaSpace.readMultiple(pt, Integer.MAX_VALUE);
            // sorted by property id
            Set<Property> pss = new TreeSet<Property>(Arrays.asList(ps));

            if (pss.size() > 0) {
                System.out.format("\n\n%-40s%-15s%-40s" , "[PropertyId]", "[FixTag]", "[Value]");
                for (Property p : pss) {
                    System.out.format("\n%-40s%-15s%-40s" ,p.getPropertyId(), fixTag.get(p.getPropertyId()), p.getPropertyValue());
                }
            }
        }
    } 

    public void addFilter(String filterId, String conditions, String comment) throws Exception {
    	System.out.println("addFilter - filterId ,conditions : "+filterId+",\t"+conditions);
        configManager.createFilter(filterId, conditions, comment);
    }

    public void addProperty(String filterId, String propertyId, String value, String comment) throws Exception {
    	System.out.println("addProperty - filterId, propertyId, value : "+filterId+",\t"+propertyId+",\t"+value);
    	configManager.createProperty("*", filterId, propertyId, value, null, comment);
    }

    public void updateFilter(String filterId, String filterConditions, String comment) {
    	System.out.println("updateFilter - filterId, conditions : "+filterId+",\t"+filterConditions);
    	configManager.updateFilter(filterId, filterConditions, comment);
    }

    public void updateProperty(String filterId, String propertyId, String propertyValue, String comment) {
    	System.out.println("updateProperty - filterId, propertyId, value : "+filterId+",\t"+propertyId+",\t"+propertyValue);
    	configManager.updateProperty(filterId, propertyId, propertyValue, null, comment);
    }

    public void deleteFilter(String filterId) {
    	System.out.println("deleteFilter - filterId : "+filterId);
        configManager.removeFilter(filterId);
    }

    public void deleteProperty(String instance, String filterId, String propertyId) {
    	System.out.println("deleteProperty - filterId, propertyId : "+filterId+",\t"+propertyId);
        configManager.removeProperty(instance, filterId, propertyId);
    }

    public boolean isPropertyExist(String filterId, String propertyId) {
        SQLQuery<Property> query = new SQLQuery<Property>(Property.class, " order by id");
        Property[] ps = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
        for (Property f : ps) {
            if (f.getPropertyId().trim().equalsIgnoreCase(propertyId) && f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                return true;
            }
        }	
        return false;
    }

    public boolean isFilterExist(String filterId) {
        SQLQuery<Filter> query = new SQLQuery<Filter>(Filter.class, " order by id");
        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
        for (Filter f : fs) {
            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                return true;
            }
        }	
        return false;
    }

    public void processAccountCsvData(final List<String[]> csv) throws Exception{

        if (csv == null || csv.isEmpty() || csv.size() < 1) {
            System.out.println("Invalid or Empty File.");
            usage();
            return;
        }

        final String[] header = csv.remove(0);

        if (header == null || header.length == 0) {
            log.error("No header provided!");
            return;
        }
        
        final String[] trimmedHeader = new String[header.length];
        for (int i = 0; i < header.length; i++) {
            trimmedHeader[i] = header[i].trim();
        }

        for (final String[] row : csv) {
            String op ="";
            String account ="";
            String ssExemptOrderFlag ="";
            
            if (row == null || row.length == 0) {
                continue;
            }
            
            log.info("Edit data = " + Arrays.asList(row).toString());
            int index = 0;
            for (final String trimmedHeaderColumn : trimmedHeader) {
                if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Operation")) {
                    op = StringUtils.trim(row[index]); // Operation
                }
                if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Account Code")) {
                    account = StringUtils.trim(row[index]).replaceAll("-", ""); // Account Code
                }
                if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("SS Exempt Order Flag")) {
                    ssExemptOrderFlag = StringUtils.trim(row[index]); // SS Exempt Order Flag
                }
                index++;
            }
            
            if (!(ssExemptOrderFlag.equalsIgnoreCase("Yes")||ssExemptOrderFlag.equalsIgnoreCase("No"))) {
                System.out.println("For Account "+account+" invalid SS Exempt Order Flag value "+ssExemptOrderFlag);
                throw new Exception("For Account "+account+" invalid SS Exempt Order Flag value "+ssExemptOrderFlag);
            }
            
            if (op == null) {
                throw new Exception("For Account "+account+" invalid Operation "+op);
            }
            
            String filterId = "RejectShortSellExempt";
            if (op.equalsIgnoreCase("deleted")) {
                String conditions = getConditions(filterId);
                if (conditions == null) {
                    return;
                }
                
                conditions = conditions.replaceAll(account+",", "").replaceAll(","+account, "").replaceAll(account, "");
                if (conditions.equalsIgnoreCase("customerId<>TRADE_PORT; daiwaAccount in ()")) {
                    deleteProperty("", filterId, "RejectShortSellExempt");
                    deleteFilter(filterId);
                } else {
                    updateFilter(filterId, conditions, "Deleted intra-day.");
                }
            } else if (op.equalsIgnoreCase("added")) {
                if (!ssExemptOrderFlag.equalsIgnoreCase("No")) {
                    return;
                }
                
                String conditions = getConditions(filterId);
                if (conditions == null) {
                    conditions = "customerId<>TRADE_PORT; daiwaAccount in ("+account+")";
                    addFilter(filterId, conditions, "Added intra-day.");
                    addProperty(filterId, "RejectShortSellExempt", "Y", "Added intra-day.");
                } else {
                    conditions = conditions.replaceFirst(account+",", "").replaceFirst(","+account, "").replaceFirst(account, "")
                                           .replaceFirst("\\)", ","+account+"\\)").replaceFirst("\\(,", "\\(");
                    updateFilter(filterId, conditions, "Added intra-day.");
                }
            } else if (op.equalsIgnoreCase("updated")) {
                if (ssExemptOrderFlag.equalsIgnoreCase("No")) {
                    String conditions = getConditions(filterId);
                    if (conditions == null) {
                        conditions = "customerId<>TRADE_PORT; daiwaAccount in ("+account+")";
                        addFilter(filterId, conditions, "Added intra-day.");
                        addProperty(filterId, "RejectShortSellExempt", "Y", "Added intra-day.");
                    } else {
                        conditions = conditions.replaceFirst(account+",", "").replaceFirst(","+account, "").replaceFirst(account, "")
                                               .replaceFirst("\\)", ","+account+"\\)").replaceFirst("\\(,", "\\(");
                        updateFilter(filterId, conditions, "Added intra-day.");
                    } 
                } else {
                    String conditions = getConditions(filterId);
                    if (conditions != null) {
                        conditions = conditions.replaceFirst(account+",", "").replaceFirst(","+account, "").replaceFirst(account, "");
                        if (conditions.equalsIgnoreCase("customerId<>TRADE_PORT; daiwaAccount in ()")) {
                            deleteProperty("", filterId, "RejectShortSellExempt");
                            deleteFilter(filterId);
                        } else {
                            updateFilter(filterId, conditions, "Deleted intra-day.");
                        }
                    } 
                }	
            } else {
                throw new Exception("For Account "+account+" invalid Operation "+op);
            }
        }
    }

    private String getConditions(String filterId) {
        for (Filter f : cfgGigaSpace.readMultiple(new SQLQuery<Filter>(Filter.class, " order by id"), Integer.MAX_VALUE)) {
            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                return f.getConditions();
            }
        }
        
        return null;
    }

    public void processCustomerCsvData(final List<String[]> csv) throws Exception{

        if (csv == null || csv.isEmpty() || csv.size() < 1) {
            System.out.println("Invalid or Empty File.");
            usage();
            return;
        }

        final String[] header = csv.remove(0);
        if (header == null || header.length == 0) {
            log.error("No header provided!");
            return;
        }
        
        final String[] trimmedHeader = new String[header.length];
        for (int i = 0; i < header.length; i++) {
            trimmedHeader[i] = header[i].trim();
        }

        for (final String[] row : csv) {

            String op ="";
            String customerID ="";
            String currMaxQuantityInLots ="";
            String currMaxTradeValue ="";
            String currAvgPxRoundingFunction ="";
            String currAvgPxDecimalPlaces ="";
            String currUnsolicitedCancelBehavior ="";
            String currUnsolicitedClOrdIDBehavior ="";
            String currSetSettlementDateOnReports ="";
            String currConvertDfdToExpire ="";
            String currCanHandleDfd ="";
            String currDfdFullyFilledOrders ="";
            String currDfdTime ="";
            String currConvertTostnetLastMkt ="";
            String currOddLotBehavior ="";
            String currDontDfdIfOddLotRemaining ="";
            String currAllowStartEndTimeOutsideMktHrs ="";
            String currDisableDRECTCrossing ="";
            String currClientMaxVolumeLimit ="";
            String currInstrumentField ="";
            String currInitialTicketNumber ="";
            String currDropPendingReports ="";
            String currOrderIdFormat ="";
            String currExecIdFormat ="";

            String currInvalidValues ="";
            boolean currInvalidFlag =false;

            if (row == null || row.length == 0) {
                continue;
            }
        
            log.info("Edit data = " + Arrays.asList(row).toString());
            int index = 0;
            for (final String trimmedHeaderColumn : trimmedHeader) {
                if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Operation")) {
                    op = StringUtils.trim(row[index]); // Operation
                }
                if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Customer ID")) {
                    customerID = StringUtils.trim(row[index]); 
                }
                if (op != null && !op.equalsIgnoreCase("Deleted")) {
                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("FIX Order Hard Limit Unit")) {
                        currMaxQuantityInLots = (new Number(StringUtils.trim(row[index]))).toString(); 
                    }
                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("FIX Order Hard Limit Amount")) {
                        currMaxTradeValue = (new Number(StringUtils.trim(row[index]))).toString();  
                    }
                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Average Price Fraction Type")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("ROUND DOWN") || StringUtils.trim(row[index]).equalsIgnoreCase("ROUND_DOWN")) {
                            currAvgPxRoundingFunction = "0";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("ROUND UP") || StringUtils.trim(row[index]).equalsIgnoreCase("ROUND_UP")) {
                            currAvgPxRoundingFunction = "1";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("NATURAL")) {
                            currAvgPxRoundingFunction = "2";
                        } else {
                            currInvalidValues = "Average Price Fraction Type - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Average Price Valid Digit")) {
                        currAvgPxDecimalPlaces = StringUtils.trim(row[index]); 
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Unsolicited Canceled Message Type")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("Canceled")) {
                            currUnsolicitedCancelBehavior = "0";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("None")) {
                            currUnsolicitedCancelBehavior = "2";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("EXPIRED")) {
                            currUnsolicitedCancelBehavior = "1";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Unsolicited Canceled Message Type - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }            	

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Unsolicited Cl Ord ID Set Type")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("ClOrdID and ClOrdID")) {
                            currUnsolicitedClOrdIDBehavior = "1";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("ClOrdID and OrgClOrdID")) {
                            currUnsolicitedClOrdIDBehavior = "2";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Space and ClOrdID")) {
                            currUnsolicitedClOrdIDBehavior = "3";
                        } else {
                            currUnsolicitedClOrdIDBehavior = "0";
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Settlement Date Set Flag")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("No")) {
                            currSetSettlementDateOnReports = "N";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Yes")) {
                            currSetSettlementDateOnReports = "Y";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Settlement Date Set Flag - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Done For Day Message Type")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("Done For Day")) {
                            currConvertDfdToExpire = "N";
                            currCanHandleDfd = "Y";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Expired")) {
                            currConvertDfdToExpire = "Y";
                            currCanHandleDfd = "Y";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("None")) {
                            currCanHandleDfd = "N";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Done For Day Message Type - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Fill Finished DFD Send Flag")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("No")) {
                            currDfdFullyFilledOrders = "N";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Yes")) {
                            currDfdFullyFilledOrders = "Y";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Fill Finished DFD Send Flag - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Done For Day Send Time")) {
                        if (!(StringUtils.trim(row[index]).equalsIgnoreCase(""))) {
                            String currDfdTimeStr = StringUtils.trim(row[index]);
                            currDfdTime = currDfdTimeStr;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Convert Last Mkt(off-floor)")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("No")) {
                            currConvertTostnetLastMkt = "N";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Yes")) {
                            currConvertTostnetLastMkt = "Y";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Convert Last Mkt(off-floor) - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Odd Lots Operation Type")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("Reject")) {
                            currOddLotBehavior = "Reject";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Accept - do not auto-send DFD until odd lot filled")) {
                            currOddLotBehavior = "IgnoreOddLot";
                            currDontDfdIfOddLotRemaining = "Y";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Accept - do auto-send DFD even if odd lot not filled")) {
                            currOddLotBehavior = "IgnoreOddLot";
                            currDontDfdIfOddLotRemaining = "N";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Odd Lots Operation Type - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Allow Start/End Time Outside Market Hours")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("No")) {
                            currAllowStartEndTimeOutsideMktHrs = "N";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Yes")) {
                            currAllowStartEndTimeOutsideMktHrs = "Y";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Allow Start/End Time Outside Market Hours - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Disable DRECT crossing")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("No")) {
                            currDisableDRECTCrossing = "0";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Yes")) {
                            currDisableDRECTCrossing = "1";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("Conditional")) {
                            currDisableDRECTCrossing = "2";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Disable DRECT crossing - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Vol High Limit For VWAP(%)")) {
                        if (!(StringUtils.trim(row[index]).equalsIgnoreCase("99"))) {
                            currClientMaxVolumeLimit = StringUtils.trim(row[index]);
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Security Adopt Tag")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("SYMBOL")) {
                            currInstrumentField = "1";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("SECURITY ID")) {
                            currInstrumentField = "0";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"Security Adopt Tag - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("Ticket Number")) {
                        if (Integer.valueOf((StringUtils.trim(row[index]))) == 99) {
                            currInitialTicketNumber = "0099";
                        } else {
                            if (Integer.valueOf((StringUtils.trim(row[index]))) < 10000) {
                                currInitialTicketNumber = StringUtils.trim(row[index]);
                            }
                            else {
                                currInitialTicketNumber = "0099";
                            }
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("DropPending")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("do not need pending new message")) {
                            currDropPendingReports = "Y";
                        } else {
                            currDropPendingReports = "N";
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("OrderIDFormat")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("32")) {
                            currOrderIdFormat = "0";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("20")) {
                            currOrderIdFormat = "1";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("16")) {
                            currOrderIdFormat = "2";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"OrderIDFormat - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }

                    if (StringUtils.trim(trimmedHeaderColumn).equalsIgnoreCase("ExecIDFormat")) {
                        if (StringUtils.trim(row[index]).equalsIgnoreCase("32")) {
                            currExecIdFormat = "0";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("20")) {
                            currExecIdFormat = "1";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("15")) {
                            currExecIdFormat = "2";
                        } else if (StringUtils.trim(row[index]).equalsIgnoreCase("7")) {
                            currExecIdFormat = "3";
                        } else {
                            currInvalidValues = currInvalidValues+"\n"+"ExecIDFormat - "+StringUtils.trim(row[index]);
                            currInvalidFlag =true;
                        }
                    }
                }
                index++;
            } 

            if (currInvalidFlag) {
                System.out.println("For Customer "+customerID+" invalid value.");
                System.out.println("Invalid values are : \n"+currInvalidValues);
                throw new Exception("For Customer "+customerID+" invalid value. \n"+"Invalid values are : \n"+currInvalidValues);
            }


            if (op != null && op.equalsIgnoreCase("Deleted")) {
                // Customer Specific filter
                String filterId= "CustomerIdSetup_"+customerID; //.replaceAll(" ", "_");

                if (!(isFilterExist(filterId))) {
                    // Ignore the customer and 
                    System.out.println("Customer ID "+customerID+" does not exist. Cant Delete.");
                    throw new Exception("Customer ID "+customerID+" does not exist. Cant Delete.");
                }


                deleteProperty("", filterId, "MaxQuantityInLots");
                deleteProperty("", filterId, "MaxTradeValue");
                deleteProperty("", filterId, "AvgPxDecimalPlaces");
                deleteProperty("", filterId, "DfdTime");
                deleteProperty("", filterId, "ClientMaxVolumeLimit");
                deleteProperty("", filterId, "InitialTicketNumber");

                deleteFilter(filterId);

                SQLQuery<Filter> query = new SQLQuery<Filter>(Filter.class, " order by id");

                // Generic Filters
                final String[] genricFilterList = {"AvgPxRoundingFunction_0", "AvgPxRoundingFunction_1", "AvgPxRoundingFunction_2"
                        , "UnsolicitedCancelBehavior_0", "UnsolicitedCancelBehavior_2", "UnsolicitedCancelBehavior_1"
                        , "UnsolicitedClOrdIDBehavior_0", "UnsolicitedClOrdIDBehavior_1", "UnsolicitedClOrdIDBehavior_2", "UnsolicitedClOrdIDBehavior_3"
                        , "SetSettlementDateOnReports_N", "SetSettlementDateOnReports_Y"
                        , "ConvertDfdToExpire_N", "ConvertDfdToExpire_Y", "CanHandleDfd_Y", "CanHandleDfd_N"
                        , "DfdFullyFilledOrders_N", "DfdFullyFilledOrders_Y", "ConvertTostnetLastMkt_N", "ConvertTostnetLastMkt_Y"
                        , "OddLotBehavior_Reject", "OddLotBehavior_IgnoreOddLot", "DontDfdIfOddLotRemaining_Y", "DontDfdIfOddLotRemaining_N"
                        , "AllowStartEndTimeOutsideMktHrs_N", "AllowStartEndTimeOutsideMktHrs_Y"
                        , "DisableDRECTCrossing_0", "DisableDRECTCrossing_1", "DisableDRECTCrossing_2", "InstrumentField_1", "InstrumentField_0"
                        , "DropPendingReports_Y", "DropPendingReports_N", "OrderIdFormat_0", "OrderIdFormat_1", "OrderIdFormat_2"
                        , "ExecIdFormat_0", "ExecIdFormat_1", "ExecIdFormat_2", "ExecIdFormat_3"};


                // AvgPxRoundingFunction_0 filters
                for (final String currFilterId : genricFilterList) {
                    filterId= currFilterId; //"AvgPxRoundingFunction_0";
                    String conditions = "";
                    Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                    for (Filter f : fs) {
                        if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                            conditions = f.getConditions();
                            break;
                        }
                    }
                    String currCondition ="";
                    if (!conditions.equalsIgnoreCase("")) {
                        currCondition =conditions;
                        currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                        if (currCondition.equalsIgnoreCase("customerId in ()")) {
                            String currProperty = filterId.split("_")[0];
                            deleteProperty("", filterId, currProperty);
                            deleteFilter(filterId);
                        } else {
                            updateFilter(filterId, currCondition, "Updated intra-day.");
                        }

                    }

                }

            } else if (op != null && op.equalsIgnoreCase("Added")) {

                // Customer Specific filter
                String filterId= "CustomerIdSetup_"+customerID; //.replaceAll(" ", "_");
                String currCondition = "customerId="+customerID;
                if (isFilterExist(filterId)) {
                    // Ignore the customer and 
                    System.out.println("Customer ID "+customerID+" already exist. Cant add.");
                    throw new Exception("Customer ID "+customerID+" already exist. Cant add.");
                    //								continue;
                } else {
                    addFilter(filterId, currCondition, "Added intra-day.");
                }

                addProperty(filterId, "MaxQuantityInLots", currMaxQuantityInLots, "Added intra-day.");
                addProperty(filterId, "MaxTradeValue", currMaxTradeValue, "Added intra-day.");
                addProperty(filterId, "AvgPxDecimalPlaces", currAvgPxDecimalPlaces, "Added intra-day.");
                addProperty(filterId, "DfdTime", currDfdTime, "Added intra-day.");
                if (!currClientMaxVolumeLimit.equalsIgnoreCase("")){
                    addProperty(filterId, "ClientMaxVolumeLimit", currClientMaxVolumeLimit, "Added intra-day.");
                }
                addProperty(filterId, "InitialTicketNumber", currInitialTicketNumber, "Added intra-day.");

                SQLQuery<Filter> query = new SQLQuery<Filter>(Filter.class, " order by id");
                // Generic Filters
                final String[] currFieldValuelst = {currAvgPxRoundingFunction, currUnsolicitedCancelBehavior, currUnsolicitedClOrdIDBehavior
                        , currSetSettlementDateOnReports, currConvertDfdToExpire, currCanHandleDfd, currDfdFullyFilledOrders
                        , currConvertTostnetLastMkt, currOddLotBehavior, currDontDfdIfOddLotRemaining, currAllowStartEndTimeOutsideMktHrs
                        , currDisableDRECTCrossing, currInstrumentField, currDropPendingReports, currOrderIdFormat, currExecIdFormat};

                final String[] currFieldNamelst = {"AvgPxRoundingFunction", "UnsolicitedCancelBehavior", "UnsolicitedClOrdIDBehavior"
                        , "SetSettlementDateOnReports", "ConvertDfdToExpire", "CanHandleDfd", "DfdFullyFilledOrders"
                        , "ConvertTostnetLastMkt", "OddLotBehavior", "DontDfdIfOddLotRemaining", "AllowStartEndTimeOutsideMktHrs"
                        , "DisableDRECTCrossing", "InstrumentField", "DropPendingReports", "OrderIdFormat", "ExecIdFormat"};

                int i = 0;
                for (final String currFieldValue : currFieldValuelst) {
                    String currFieldName = currFieldNamelst[i++];
                    if (currFieldValue.equalsIgnoreCase("0")) {
                        filterId= currFieldName+"_0"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "0", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }
                    } else if (currFieldValue.equalsIgnoreCase("1")) {
                        filterId= currFieldName+"_1"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "1", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }
                    }  else if (currFieldValue.equalsIgnoreCase("2")) {
                        filterId= currFieldName+"_2"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "2", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }
                    }  else if (currFieldValue.equalsIgnoreCase("3")) {
                        filterId= currFieldName+"_3"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "3", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }
                    }  else if (currFieldValue.equalsIgnoreCase("N")) {
                        filterId= currFieldName+"_N"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "N", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }
                    }  else if (currFieldValue.equalsIgnoreCase("Y")) {
                        filterId= currFieldName+"_Y"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "Y", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }
                    }  else if (currFieldValue.equalsIgnoreCase("Reject")) {
                        filterId= currFieldName+"_Reject"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "Reject", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }
                    }  else if (currFieldValue.equalsIgnoreCase("IgnoreOddLot")) {
                        filterId= currFieldName+"_IgnoreOddLot"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "IgnoreOddLot", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }
                    }	
                }

            } else if (op != null && op.equalsIgnoreCase("Updated")) {

                // Customer Specific filter
                String filterId= "CustomerIdSetup_"+customerID; //.replaceAll(" ", "_");

                if (!(isFilterExist(filterId))) {
                    // Ignore the customer and 
                    System.out.println("Customer ID "+customerID+" does not exist. Cant Update.");
                    throw new Exception("Customer ID "+customerID+" does not exist. Cant Update.");
                    //								continue;
                }

                if (isPropertyExist(filterId, "MaxQuantityInLots")){
                    updateProperty(filterId, "MaxQuantityInLots", currMaxQuantityInLots, "Updated intra-day.");
                } else {
                    addProperty(filterId, "MaxQuantityInLots", currMaxQuantityInLots, "Updated intra-day.");
                }

                if (isPropertyExist(filterId, "MaxTradeValue")){
                    updateProperty(filterId, "MaxTradeValue", currMaxTradeValue, "Updated intra-day.");
                } else {
                    addProperty(filterId, "MaxTradeValue", currMaxTradeValue, "Updated intra-day.");
                }

                if (isPropertyExist(filterId, "AvgPxDecimalPlaces")){
                    updateProperty(filterId, "AvgPxDecimalPlaces", currAvgPxDecimalPlaces, "Updated intra-day.");
                } else {
                    addProperty(filterId, "AvgPxDecimalPlaces", currAvgPxDecimalPlaces, "Updated intra-day.");
                }

                if (isPropertyExist(filterId, "DfdTime")){
                    updateProperty(filterId, "DfdTime", currDfdTime, "Updated intra-day.");
                } else {
                    addProperty(filterId, "DfdTime", currDfdTime, "Updated intra-day.");
                }

                if (!currClientMaxVolumeLimit.equalsIgnoreCase("")){
                    if (isPropertyExist(filterId, "ClientMaxVolumeLimit")){
                        updateProperty(filterId, "ClientMaxVolumeLimit", currClientMaxVolumeLimit, "Updated intra-day.");
                    } else {
                        addProperty(filterId, "ClientMaxVolumeLimit", currClientMaxVolumeLimit, "Updated intra-day.");
                    }
                } else {
                    if (isPropertyExist(filterId, "ClientMaxVolumeLimit")){
                        deleteProperty("", filterId, "ClientMaxVolumeLimit");
                    }	
                }

                if (isPropertyExist(filterId, "InitialTicketNumber")){
                    updateProperty(filterId, "InitialTicketNumber", currInitialTicketNumber, "Updated intra-day.");
                } else {
                    addProperty(filterId, "InitialTicketNumber", currInitialTicketNumber, "Updated intra-day.");
                }

                SQLQuery<Filter> query = new SQLQuery<Filter>(Filter.class, " order by id");
                // Generic Filters
                final String[] currFieldValuelst = {currAvgPxRoundingFunction, currUnsolicitedCancelBehavior, currUnsolicitedClOrdIDBehavior
                        , currSetSettlementDateOnReports, currConvertDfdToExpire, currCanHandleDfd, currDfdFullyFilledOrders
                        , currConvertTostnetLastMkt, currOddLotBehavior, currDontDfdIfOddLotRemaining, currAllowStartEndTimeOutsideMktHrs
                        , currDisableDRECTCrossing, currInstrumentField, currDropPendingReports, currOrderIdFormat, currExecIdFormat};

                final String[] currFieldNamelst = {"AvgPxRoundingFunction", "UnsolicitedCancelBehavior", "UnsolicitedClOrdIDBehavior"
                        , "SetSettlementDateOnReports", "ConvertDfdToExpire", "CanHandleDfd", "DfdFullyFilledOrders"
                        , "ConvertTostnetLastMkt", "OddLotBehavior", "DontDfdIfOddLotRemaining", "AllowStartEndTimeOutsideMktHrs"
                        , "DisableDRECTCrossing", "InstrumentField", "DropPendingReports", "OrderIdFormat", "ExecIdFormat"};

                int i = 0;
                for (final String currFieldValue : currFieldValuelst) {
                    String currFieldName = currFieldNamelst[i++];
                    if (currFieldValue.equalsIgnoreCase("0")) {
                        filterId= currFieldName+"_0"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        String currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "0", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }

                        // Remove entries from old filters
                        final String[] posibleValuelst = {"1", "2", "3"};
                        for (final String posibleValue : posibleValuelst) {
                            filterId= currFieldName+"_"+posibleValue; //"AvgPxRoundingFunction_0";
                            conditions = "";
                            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                            for (Filter f : fs) {
                                if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                    conditions = f.getConditions();
                                    break;
                                }
                            }
                            currCondition ="";
                            if (!conditions.equalsIgnoreCase("")) {
                                currCondition =conditions;
                                currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                    deleteProperty("", filterId, currFieldName);
                                    deleteFilter(filterId);
                                } else {
                                    updateFilter(filterId, currCondition, "Updated intra-day.");
                                }

                            }

                        }


                    } else if (currFieldValue.equalsIgnoreCase("1")) {
                        filterId= currFieldName+"_1"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        String currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "1", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }

                        // Remove entries from old filters
                        final String[] posibleValuelst = {"0", "2", "3"};
                        for (final String posibleValue : posibleValuelst) {
                            filterId= currFieldName+"_"+posibleValue; //"AvgPxRoundingFunction_0";
                            conditions = "";
                            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                            for (Filter f : fs) {
                                if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                    conditions = f.getConditions();
                                    break;
                                }
                            }
                            currCondition ="";
                            if (!conditions.equalsIgnoreCase("")) {
                                currCondition =conditions;
                                currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                    deleteProperty("", filterId, currFieldName);
                                    deleteFilter(filterId);
                                } else {
                                    updateFilter(filterId, currCondition, "Updated intra-day.");
                                }

                            }

                        }
                    }  else if (currFieldValue.equalsIgnoreCase("2")) {
                        filterId= currFieldName+"_2"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        String currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "2", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }

                        // Remove entries from old filters
                        final String[] posibleValuelst = {"1", "0", "3"};
                        for (final String posibleValue : posibleValuelst) {
                            filterId= currFieldName+"_"+posibleValue; //"AvgPxRoundingFunction_0";
                            conditions = "";
                            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                            for (Filter f : fs) {
                                if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                    conditions = f.getConditions();
                                    break;
                                }
                            }
                            currCondition ="";
                            if (!conditions.equalsIgnoreCase("")) {
                                currCondition =conditions;
                                currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                    deleteProperty("", filterId, currFieldName);
                                    deleteFilter(filterId);
                                } else {
                                    updateFilter(filterId, currCondition, "Updated intra-day.");
                                }
                            }

                        }
                    }  else if (currFieldValue.equalsIgnoreCase("3")) {
                        filterId= currFieldName+"_3"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        String currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "3", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }

                        // Remove entries from old filters
                        final String[] posibleValuelst = {"1", "2", "0"};
                        for (final String posibleValue : posibleValuelst) {
                            filterId= currFieldName+"_"+posibleValue; //"AvgPxRoundingFunction_0";
                            conditions = "";
                            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                            for (Filter f : fs) {
                                if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                    conditions = f.getConditions();
                                    break;
                                }
                            }
                            currCondition ="";
                            if (!conditions.equalsIgnoreCase("")) {
                                currCondition =conditions;
                                currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                    deleteProperty("", filterId, currFieldName);
                                    deleteFilter(filterId);
                                } else {
                                    updateFilter(filterId, currCondition, "Updated intra-day.");
                                }

                            }

                        }
                    }  else if (currFieldValue.equalsIgnoreCase("N")) {
                        filterId= currFieldName+"_N"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        String currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "N", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }

                        // Remove entries from old filters
                        final String[] posibleValuelst = {"Y"};
                        for (final String posibleValue : posibleValuelst) {
                            filterId= currFieldName+"_"+posibleValue; //"AvgPxRoundingFunction_0";
                            conditions = "";
                            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                            for (Filter f : fs) {
                                if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                    conditions = f.getConditions();
                                    break;
                                }
                            }
                            currCondition ="";
                            if (!conditions.equalsIgnoreCase("")) {
                                currCondition =conditions;
                                currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                    deleteProperty("", filterId, currFieldName);
                                    deleteFilter(filterId);
                                } else {
                                    updateFilter(filterId, currCondition, "Updated intra-day.");
                                }

                            }

                        }

                        // In case of CanHandleDFD=N Remove entries from ConvertDfdToExpire filters
                        if (currFieldName.equalsIgnoreCase("CanHandleDfd")){
                            final String[] posibleValuelst_2 = {"Y", "N"};
                            for (final String posibleValue : posibleValuelst_2) {
                                filterId= "ConvertDfdToExpire_"+posibleValue; //"AvgPxRoundingFunction_0";
                                conditions = "";
                                fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                                for (Filter f : fs) {
                                    if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                        conditions = f.getConditions();
                                        break;
                                    }
                                    //					    		System.out.println(f);
                                }
                                currCondition ="";
                                if (!conditions.equalsIgnoreCase("")) {
                                    currCondition =conditions;
                                    currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                    if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                        deleteProperty("", filterId, "ConvertDfdToExpire");
                                        deleteFilter(filterId);
                                    } else {
                                        updateFilter(filterId, currCondition, "Updated intra-day.");
                                    }

                                }

                            }
                        }

                    }  else if (currFieldValue.equalsIgnoreCase("Y")) {
                        filterId= currFieldName+"_Y"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        String currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "Y", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }

                        // Remove entries from old filters
                        final String[] posibleValuelst = {"N"};
                        for (final String posibleValue : posibleValuelst) {
                            filterId= currFieldName+"_"+posibleValue; //"AvgPxRoundingFunction_0";
                            conditions = "";
                            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                            for (Filter f : fs) {
                                if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                    conditions = f.getConditions();
                                    break;
                                }
                            }
                            currCondition ="";
                            if (!conditions.equalsIgnoreCase("")) {
                                currCondition =conditions;
                                currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                    deleteProperty("", filterId, currFieldName);
                                    deleteFilter(filterId);
                                } else {
                                    updateFilter(filterId, currCondition, "Updated intra-day.");
                                }

                            }

                        }
                    }  else if (currFieldValue.equalsIgnoreCase("Reject")) {
                        filterId= currFieldName+"_Reject"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        String currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "Reject", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }

                        // Remove entries from old filters
                        final String[] posibleValuelst = {"IgnoreOddLot"};
                        for (final String posibleValue : posibleValuelst) {
                            filterId= currFieldName+"_"+posibleValue; //"AvgPxRoundingFunction_0";
                            conditions = "";
                            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                            for (Filter f : fs) {
                                if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                    conditions = f.getConditions();
                                    break;
                                }
                            }
                            currCondition ="";
                            if (!conditions.equalsIgnoreCase("")) {
                                currCondition =conditions;
                                currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                    deleteProperty("", filterId, currFieldName);
                                    deleteFilter(filterId);
                                } else {
                                    updateFilter(filterId, currCondition, "Updated intra-day.");
                                }

                            }

                        }

                        // In case of OddLotBehavior=Reject Remove entries from DontDfdIfOddLotRemaining filters
                        if (currFieldName.equalsIgnoreCase("OddLotBehavior")){
                            final String[] posibleValuelst_2 = {"Y", "N"};
                            for (final String posibleValue : posibleValuelst_2) {
                                filterId= "DontDfdIfOddLotRemaining_"+posibleValue; //"AvgPxRoundingFunction_0";
                                conditions = "";
                                fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                                for (Filter f : fs) {
                                    if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                        conditions = f.getConditions();
                                        break;
                                    }
                                }
                                currCondition ="";
                                if (!conditions.equalsIgnoreCase("")) {
                                    currCondition =conditions;
                                    currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                    if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                        deleteProperty("", filterId, "DontDfdIfOddLotRemaining");
                                        deleteFilter(filterId);
                                    } else {
                                        updateFilter(filterId, currCondition, "Updated intra-day.");
                                    }

                                }

                            }
                        }	

                    }  else if (currFieldValue.equalsIgnoreCase("IgnoreOddLot")) {
                        filterId= currFieldName+"_IgnoreOddLot"; //"AvgPxRoundingFunction_0";
                        String conditions = "";
                        Filter[] fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                        for (Filter f : fs) {
                            if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                conditions = f.getConditions();
                                break;
                            }
                        }
                        String currCondition ="";
                        if (conditions.equalsIgnoreCase("")) {
                            currCondition = "customerId in ("+customerID+")";
                            addFilter(filterId, currCondition, "Added intra-day.");
                            addProperty(filterId, currFieldName, "IgnoreOddLot", "Added intra-day.");
                        } else {
                            currCondition =conditions;
                            currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                            currCondition =currCondition.replaceFirst("\\)", ","+customerID+"\\)").replaceFirst("\\(,", "\\(");
                            updateFilter(filterId, currCondition, "Added intra-day.");
                        }

                        // Remove entries from old filters
                        final String[] posibleValuelst = {"Reject"};
                        for (final String posibleValue : posibleValuelst) {
                            filterId= currFieldName+"_"+posibleValue; //"AvgPxRoundingFunction_0";
                            conditions = "";
                            fs = cfgGigaSpace.readMultiple(query, Integer.MAX_VALUE);
                            for (Filter f : fs) {
                                if (f.getFilterId().trim().equalsIgnoreCase(filterId)) {
                                    conditions = f.getConditions();
                                    break;
                                }
                            }
                            currCondition ="";
                            if (!conditions.equalsIgnoreCase("")) {
                                currCondition =conditions;
                                currCondition =currCondition.replaceAll(customerID+",", "").replaceAll(","+customerID, "").replaceAll(customerID, "");
                                if (currCondition.equalsIgnoreCase("customerId in ()")) {
                                    deleteProperty("", filterId, currFieldName);
                                    deleteFilter(filterId);
                                } else {
                                    updateFilter(filterId, currCondition, "Updated intra-day.");
                                }

                            }

                        }
                    }	
                }
            } else {
                throw new Exception("Customer ID "+customerID+" unknown operation."+op);
                //							continue;
            }
        }
    }


    private static List<String[]> getCsvContents(final String filePath) throws IOException {

        final CSVReader csvReader = new CSVReader(new FileReader(filePath), 
                CSVParser.DEFAULT_SEPARATOR,
                CSVParser.DEFAULT_QUOTE_CHARACTER, 
                CSVParser.DEFAULT_ESCAPE_CHARACTER, 
                0, 
                CSVParser.DEFAULT_STRICT_QUOTES);

        return csvReader.readAll();
    }

    private static ClassPathXmlApplicationContext getContext() {
        CONTEXT =  CONTEXT == null ? new ClassPathXmlApplicationContext("classpath*:/META-INF/spring/ConfigUpdaterCommandLine.xml")
        : CONTEXT;
        return CONTEXT;
    }
}

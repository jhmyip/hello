package com.daiwacm.dats.configManager.util;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daiwacm.dats.configManager.Filter;
import com.daiwacm.dats.configManager.Property;
import com.daiwacm.dats.configManager.common.ConfigurableProperty;
import com.daiwacm.dats.configManager.common.ConfigurableTag;
import com.daiwacm.dats.configManager.common.IConfigurable;

public class ConfigUtils {
	private static final Logger log = LoggerFactory.getLogger(ConfigUtils.class);

    public static Date getDate(int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        // subtracting 1 because month is 0 based in the set() method 
        cal.set(year, month-1, day);
        return cal.getTime();
    }

	/**
	 * obtain the set of configurable properties based on
	 * 	1. methods annotated with ConfigurableProperty
	 * 	2. setter method 
	 *   
	 * @param configurableClass
	 * @return the set of configurable properties
	 */
	public static Map<String, Method> getConfigurableProperties(Class<? extends IConfigurable> configurableClass) {
	    log.debug("Getting ConfigurableProperties from configurableClass {}", configurableClass);
	    
		Map<String, Method> properties = new LinkedHashMap<String, Method>();
		
		for (Method m : configurableClass.getMethods()) {
			String methodName = m.getName();
			if (Modifier.isStatic(m.getModifiers())) {
				log.debug("skip static method {}", methodName);
				continue;
			}
			
			String propertyName = null;
			if (methodName.startsWith("set")) {
			    propertyName = methodName.substring(3);
			}
			
			ConfigurableProperty cfgPty = m.getAnnotation(ConfigurableProperty.class);
			if (cfgPty != null && !cfgPty.propertyName().isEmpty()) {
			    propertyName = cfgPty.propertyName();
			}

			if (propertyName != null) {
	            if (m.getParameterTypes().length > 1) {
	                StringBuilder sb = new StringBuilder();
	                for (Class<?> c : m.getParameterTypes()) {
	                    if (sb.length() > 0) {
	                        sb.append(", ");
	                    }
	                    sb.append(c.getSimpleName());
	                }
	                log.warn("Ignoring setter {}.{}({}) with more than one parameter", new Object[]{
	                        configurableClass.getSimpleName(), m.getName(), sb.toString() });
	                continue;
	            }
				properties.put(propertyName, m);
				log.debug("Added configurable property {} for method {}", propertyName, methodName);
			}
		}
		
		return properties;
	}
	
	
	public static Map<String, Method> getConfigurableTagMethods(Class<? extends IConfigurable> configurableClass) {
		
	    log.debug("Getting getConfigurableTagMethods from configurableClass {}", configurableClass);
	    
		Map<String, Method> tagMethods = new LinkedHashMap<String, Method>();

		for (Method m : configurableClass.getMethods()) {
			String methodName = m.getName();
			if (Modifier.isStatic(m.getModifiers())) {
				log.debug("skip static method {}", methodName);
				continue;
			}

			ConfigurableTag cfgTag = m.getAnnotation(ConfigurableTag.class);
			if (cfgTag == null) {
			    continue;
			}
			
			String filterTagName = null;
		    if (!cfgTag.tagName().isEmpty()) {
		        filterTagName = cfgTag.tagName();
		    } else if (methodName.startsWith("get")) {
                filterTagName = Character.toLowerCase(methodName.charAt(3)) + methodName.substring(4);
		    }
		    
		    if (filterTagName != null) {
		        tagMethods.put(filterTagName, m);
		    }
		}

		return tagMethods;
	}
	
    /**
     * Select one filter from the input Filter list order matching 
     * <ol> 
     * <li>	pick the highest precedence tag from each filter </li> 
     * <li>	if the top two tags are different, the filter with the highest one will be chosen </li>
     * <li>	otherwise,  keep the filters with the top tag and drop all other filters. </li>
     * <li>	pick the next highest precedence tag from each filter in step iii and repeat step ii </li>
     * </ol>
     * Select one filter from the input Filter list for wild card matching  
     * <ol> 
     * <li>	pick the highest precedence tag from each filter </li> 
     * <li>	if the top tags are different, the filter with the higher precedence will be discarded </li>
     * <li>	pick the next highest precedence tag from each filter in step ii and repeat step ii </li>
     * </ol>
     * @param passedFilters
     * @param wildcard
     * @return the selected filter
     */
    public static Filter selectFilter(List<Filter> passedFilters, boolean wildcard) {

        if (passedFilters.isEmpty()) {
            return null;
        }
        
        Filter[] filters = passedFilters.toArray(new Filter[passedFilters.size()]);
        Arrays.sort(filters);
	    return wildcard ? filters[0] : filters[filters.length - 1];

    }
    
	public static Method getMethod(Class<?> configurableClass, String methodName) {
		try {
			return configurableClass.getMethod(methodName);
		} catch (NoSuchMethodException e) {
		}
		return null;
	}
	
	public static Object invoke(Method m, Object obj) {
		try {
			return m.invoke(obj);
		} catch (Exception e) {
		}

		return null;
	}
	
	public static Object invoke(Class<?> configurableClass, String methodName, Object obj) {
		try {
			return configurableClass.getMethod(methodName).invoke(obj);
		} catch (NoSuchMethodException e) {
			log.error("configurableClass {} doesn't contain method {}", new Object[] {configurableClass.getName(), methodName}, e);
		} catch (Exception e) {
		}

		return null;
	}
	
	public static Integer getFixTagNum(String tag) {
		try {
			Class<?> tagClass = Class.forName("com.daiwacm.dats.orm.quickfix.fields." + tag);
			return tagClass.getField("FIELD").getInt(null);
		} catch (Exception e) {
			log.warn("tag {} is not defined in com.daiwacm.dats.orm.quickfix", tag); 
		}
		return null;
	}
	
	public static Integer getFixTagNum(Property property, boolean usePropertyTagFix) {
		// first try using reflection
		Integer fixTag = getFixTagNum(property.getPropertyId());
		if (fixTag == null && usePropertyTagFix) {
			log.debug("get tag# for {} using PropertyTag config", property.getPropertyId());
			fixTag = property.getPropertyTag().getFixTag();
		}
		return fixTag;
	}

}

package com.daiwacm.dats.configManager.util;

import com.gigaspaces.annotation.pojo.*;

import javax.persistence.*;

@Entity
@Table(name = "IdCounter")
@SpaceClass
public class IdCounterEntry {

	private Integer id;

	private Integer currentId;
    private Integer idRangeSize;
    private String className;

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	@SpaceId(autoGenerate = false)
    public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public IdCounterEntry() {}

    public IdCounterEntry(int currentId,int idRangeSize, String className) {
        this.idRangeSize = idRangeSize;
        this.currentId = currentId; 
        this.className = className;
    }

    public Integer getCurrentId() {
        return currentId;
    }

    public void setCurrentId(Integer currentId) {
        this.currentId = currentId;
    }

    public Integer getIdRangeSize() {
        return idRangeSize;
    }

    public void setIdRangeSize(Integer idRangeSize) {
        this.idRangeSize = idRangeSize;
    }

    @SpaceExclude
    @Transient
    public int[] getIdRange() {
        int endId = currentId + idRangeSize;
        int[] range = new int[]{currentId, endId-1};
        currentId += idRangeSize;
        return range;

    }

    @SpaceRouting
    protected Integer getRouting() {
        return 0;
    }                                          
    protected void setRouting(Integer routing) {}

    @Override
	public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("IdCounterEntry [")
          .append("id=").append(id)
          .append(", currentId=").append(currentId)
		  .append(", idRangeSize=").append(idRangeSize)
		  .append(", className=").append(className)
		  .append("]");
		return sb.toString();
	}

}

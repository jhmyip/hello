package com.daiwacm.dats.configManager.util;

public interface IdGenerator {
    Integer generateId();
}

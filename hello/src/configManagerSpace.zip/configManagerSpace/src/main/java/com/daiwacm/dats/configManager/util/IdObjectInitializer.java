package com.daiwacm.dats.configManager.util;

import java.util.List;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.cluster.ClusterInfoContext;
import org.openspaces.core.space.mode.AfterSpaceModeChangeEvent;
import org.openspaces.core.space.mode.PostPrimary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.daiwacm.dats.configManager.Filter;
import com.daiwacm.dats.configManager.FilterTag;
import com.daiwacm.dats.configManager.Property;
import com.j_spaces.core.client.SQLQuery;
import com.j_spaces.core.client.UpdateModifiers;

/**
 * Date: Nov 23, 2010
 * Johnny
 * Enhanced to support id per table
 */
public class IdObjectInitializer {
	private static final Logger log = LoggerFactory.getLogger(IdObjectInitializer.class);
	
    @Autowired
    @Qualifier("cfgGigaSpace")
    private GigaSpace cfgGigaSpace;
    
    @ClusterInfoContext
    private ClusterInfo clusterInfo;
    private int idRangeSize = 100;		// configurable in spring
    private int initialValue = 1;		// configurable in spring file
    private List<String> initialLoadEntries; // configurable in spring

    public List<String> getInitialLoadEntries() {
		return initialLoadEntries;
	}

	public void setInitialLoadEntries(List<String> initialLoadEntries) {
		this.initialLoadEntries = initialLoadEntries;
	}

	/**
     * Sets the range size,
     * @param idRangeSize
     */
    public void setIdRangeSize(int idRangeSize) {
        this.idRangeSize = idRangeSize;
    }

    @PostPrimary
    public void init(AfterSpaceModeChangeEvent event) {
    	if (!event.getSpace().getName().equals(cfgGigaSpace.getSpace().getName())) {
    		return;
    	}
    	
    	cfgGigaSpace.getSpace().setUpdateModifiers(UpdateModifiers.NO_RETURN_VALUE | UpdateModifiers.UPDATE_OR_WRITE);
    	
    	if (initialLoadEntries == null) {
        	log.info("Empty initialLoadEntries ");
        	return;
    	}
    	log.info("loading initial entries");
    	for (String className : initialLoadEntries) {

    		Integer maxId = getMaxId(className);
            if (maxId != null)
            	initialValue = maxId + 1;
    	
	        if (shouldWriteIdObjectToSpace()) {
	        	IdCounterEntry template = new IdCounterEntry();
	        	template.setClassName(className);
	            IdCounterEntry existingEntry = cfgGigaSpace.read(template); 
	            if (existingEntry == null) {
	            	log.info("\tsetting entry " + className + " " + idRangeSize);
	                cfgGigaSpace.write(new IdCounterEntry(initialValue, idRangeSize, className));
	            } else {
	            	log.debug("existingEntry.getCurrentId {}, initialValue {}", existingEntry.getCurrentId(), initialValue);
	            	if (existingEntry.getCurrentId()<initialValue) {
	            		log.info("update currentId from {} to {}", existingEntry.getCurrentId(), initialValue);
	            		existingEntry.setCurrentId(initialValue);
	            		cfgGigaSpace.write(existingEntry);
	            		log.info("\toverride entry {}", existingEntry);
	            	} else {
	            		log.info("\tloaded entry {}", existingEntry);
	            	}
	            }
	        }
    	}
    }
    
    
    public Integer getMaxId(String className) {
    	Integer maxId=null;

    	if (className.equals("com.daiwacm.dats.configManager.FilterTag")) {
        	SQLQuery<FilterTag> query1 = new SQLQuery<FilterTag>(FilterTag.class, " ORDER BY id DESC");
        	FilterTag[] fts = cfgGigaSpace.readMultiple(query1, Integer.MAX_VALUE);
        	if (fts.length>0)
        		maxId = fts[0].getId();
    	} else if (className.equals("com.daiwacm.dats.configManager.Property")) {
        	SQLQuery<Property> query1 = new SQLQuery<Property>(Property.class, " ORDER BY id DESC");
        	Property[] pps = cfgGigaSpace.readMultiple(query1, Integer.MAX_VALUE);
        	if (pps.length>0)
        		maxId = pps[0].getId();
        } else if (className.equals("com.daiwacm.dats.configManager.Filter")) {
        	SQLQuery<Filter> query1 = new SQLQuery<Filter>(Filter.class, " ORDER BY id DESC");
        	Filter[] fss = cfgGigaSpace.readMultiple(query1, Integer.MAX_VALUE);
        	if (fss.length>0)
        		maxId = fss[0].getId();
        } else {
        	log.warn("unsupport class {}", className);
        }

    	log.debug("className {}, maxId {}", className, maxId);
    	return maxId;
    }

    //return true if we don't have a clusterInfo/instance id, or if this the first
    //primary instance in the cluster
    private boolean shouldWriteIdObjectToSpace() {
        if  (clusterInfo == null)
            return true;
        if (clusterInfo.getInstanceId() == null)
            return true;
        if (clusterInfo.getInstanceId() == 1)
            return true;
        return false;
    }

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("\n");
		
    	for (String className : initialLoadEntries) {
    		sb.append(className).append("\t maxVal=");
    		Integer initVal = getMaxId(className);
    		sb.append(initVal).append("\n");
    	}
    	
    	return sb.toString();
	}
}

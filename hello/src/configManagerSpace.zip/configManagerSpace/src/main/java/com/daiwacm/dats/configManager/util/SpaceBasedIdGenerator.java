package com.daiwacm.dats.configManager.util;


import net.jini.core.lease.Lease;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.transaction.manager.LocalJiniTxManagerConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.j_spaces.core.IJSpace;
import com.j_spaces.core.client.ReadModifiers;
import com.j_spaces.core.client.UpdateModifiers;

/**
 * Based on GigaSpaces.
 */
public class SpaceBasedIdGenerator implements IdGenerator {
	private static final Logger log = LoggerFactory.getLogger(SpaceBasedIdGenerator.class);
	
	private int currentId = 0;

    private GigaSpace cfgGigaSpace;
	
	private String className;
    private int idLimit = -1;
    private IdCounterEntry template;

    public SpaceBasedIdGenerator(GigaSpace gigaSpace, String className) {
    	setGigaSpace(gigaSpace);
    	this.className = className;
    	template = new IdCounterEntry();
		template.setClassName(className);
	}

	@Transactional(propagation=Propagation.REQUIRES_NEW)
    public synchronized Integer generateId() {
        if (currentId < 0 || currentId > idLimit) {
            getNextIdBatchFromSpace();
        }
        return currentId++;
    }
    
    private void getNextIdBatchFromSpace() {
	    	
        IdCounterEntry idCounterEntry = cfgGigaSpace.read(template, 10000);
    	
        if (idCounterEntry == null) {
            throw new RuntimeException("Could not get ID object from Space");
        }
        int[] range = idCounterEntry.getIdRange();
        currentId = range[0];
        idLimit = range[1];
        log.debug("getNextIdBatchFromSpace currentId {} idLimit {}", currentId, idLimit);
        cfgGigaSpace.write(idCounterEntry, Lease.FOREVER, 5000, UpdateModifiers.UPDATE_ONLY);
    }

    @SuppressWarnings("unused")
    private void getNextIdBatchFromSpaceTrx() {
    	// TODO fix EXCLUSIVE_READ_LOCK issue
        IJSpace space = cfgGigaSpace.getSpace(); 
		space.setReadModifiers(ReadModifiers.EXCLUSIVE_READ_LOCK);
		
		// TODO can initialize transaction manager when this class is constructed
		PlatformTransactionManager transactionManager;
        try {
            transactionManager = new LocalJiniTxManagerConfigurer(space).transactionManager();
        } catch (Exception e) {
            log.error("Could not get transaction manager!", e);
            return;
        }
		
		TransactionStatus status = transactionManager.getTransaction(new DefaultTransactionDefinition());
		try { 
		    IdCounterEntry idCounterEntry = cfgGigaSpace.read(template, 10000);
		    
		    if (idCounterEntry == null) {
		        throw new RuntimeException("Could not get ID object from Space");
		    }
		    int[] range = idCounterEntry.getIdRange();
		    currentId = range[0];
		    idLimit = range[1];
		    log.debug("getNextIdBatchFromSpace currentId {} idLimit {}", currentId, idLimit);
		    cfgGigaSpace.write(idCounterEntry, Lease.FOREVER, 5000, UpdateModifiers.UPDATE_ONLY);
		} 
		catch (Exception e) {
		    log.error("Could not commit transaction!", e);
		    transactionManager.rollback(status);
		    return;
		}
		transactionManager.commit(status);
    }
    
    public void setGigaSpace(GigaSpace gigaSpace) {
        this.cfgGigaSpace = gigaSpace;
    }

	@Override
	public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("SpaceBasedIdGenerator [")
	      .append("currentId=").append(currentId)
	      .append(", className=").append(className)
	      .append(", idLimit=").append(idLimit)
	      .append("]");
	    
	    return sb.toString();
	}
}





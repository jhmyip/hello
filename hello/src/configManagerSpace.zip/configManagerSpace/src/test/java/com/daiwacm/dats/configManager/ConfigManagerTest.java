package com.daiwacm.dats.configManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.daiwacm.dats.configManager.common.BaseTest;
import com.daiwacm.dats.configManager.common.Order;
import com.daiwacm.dats.configManager.util.IdCounterEntry;
import com.daiwacm.dats.configManager.util.IdGenerator;
import com.daiwacm.dats.configManager.util.IdObjectInitializer;
import com.daiwacm.dats.configManager.util.SpaceBasedIdGenerator;
import com.daiwacm.dats.type.Side;

@DirtiesContext(classMode=ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringJUnit4ClassRunner.class)
public class ConfigManagerTest extends BaseTest {
    
    @SuppressWarnings("unused")
	private static final Logger log = LoggerFactory.getLogger(ConfigManagerTest.class);
    
	@Autowired
	IdObjectInitializer idi;
	
	@Autowired
	private ConfigManager genericConfigManager;

    @Test
    public void idGenerateTest() {
    	assertEquals(4, cfgGigaSpace.count(new IdCounterEntry(), Integer.MAX_VALUE));
    	
    	IdGenerator idgFilter = new SpaceBasedIdGenerator(cfgGigaSpace, Filter.class.getName());

    	int[] i = new int[18];
    	
    	for (int k=0; k<i.length; k++) {
    		i[k] = idgFilter.generateId();
    		assertTrue(i[k]>0);
    		if (k > 0) {
    		    assertEquals(i[k]-1, i[k-1]);
    		}
    	}
    	
    	// TODO is following line still needed?
    	new SpaceBasedIdGenerator(cfgGigaSpace, Filter.class.getName());
    	for (int k=0; k<i.length; k++) {
    	    i[k] = idgFilter.generateId();
    	    assertTrue(i[k]>0);
    	    if (k > 0) {
    	        assertEquals(i[k]-1, i[k-1]);
    	    }
    	}
    }
    
    @Test
    public void enrichOrderTest() {
    	// HSBC_POV and HK_POV
    	Order order2 = new Order("0005.HK", "POV", Side.SELL, 1000, "LIMIT", 10.0);
    	configManager.enrichOrder(order2);
    	assertEquals("35", order2.getMaxVol());
    	assertEquals("PASS", order2.getExecStyle());
    	
    	// HSBC_POV and HK_POV
    	Order order3 = new Order("0001.HK", "VWAP", Side.SELL, 1000, "LIMIT", 10.0);
    	configManager.enrichOrder(order3);
    	assertEquals("31.5", order3.getMaxVol());
    	assertEquals("PASS", order3.getExecStyle());
    	assertEquals("Y", order3.getField(6077));

    	Order order4 = new Order("0013.HK", "VWAP", Side.SELL, 1000, "LIMIT", 10.0);
    	configManager.enrichOrder(order4);
    	assertEquals("N", order4.getField(6077));
    }
    
    @Test
    public void createFilterPropertyTest() throws Exception {
    	final String filterTag = "HSBC_POV2";
    	
		configManager.createFilter(filterTag, "strategy=POV; symbol=0005.HK; qty>400;", "testing");
		configManager.createProperty("*", filterTag, "StartTime", "10:30 +0800", null, "testing");
		
    	Filter ft = new Filter();
    	ft.setFilterId("HSBC_POV2");
    	Filter f = cfgGigaSpace.read(ft, Integer.MAX_VALUE);
    	assertNotNull(f);

    	Property pt = new Property();
    	pt.setFilterId(filterTag);
    	Property p = cfgGigaSpace.read(pt, Integer.MAX_VALUE);

    	assertNotNull(p);
    	assertEquals(filterTag, p.getFilterId());
    }
    
    @Test
    public void getPropertyTest() {
    	Property pt = genericConfigManager.getProperty("XHKG", "Field1");
    	assertNotNull(pt);
    	assertEquals("XXX", pt.getPropertyValue());
    }

    @Test
    public void getPropertiesTest() {
    	Order order = new Order("0005.HK", "POV", Side.SELL, 1000, "LIMIT", 10.0);
    	Map<String, Property> pts = configManager.getProperties(order, new String[] {"MaxVol", "ExecStyle"});
    	assertEquals("35", pts.get("MaxVol").getPropertyValue());
    	assertEquals("PASS", pts.get("ExecStyle").getPropertyValue());
    }
}

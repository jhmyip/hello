package com.daiwacm.dats.configManager;

import java.io.File;
import java.io.FileInputStream;

import javax.sql.DataSource;

import org.dbunit.DatabaseTestCase;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.operation.DatabaseOperation;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openspaces.core.GigaSpace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.daiwacm.dats.configManager.common.Order;
import com.daiwacm.dats.configManager.util.IdCounterEntry;
import com.daiwacm.dats.configManager.util.IdGenerator;
import com.daiwacm.dats.configManager.util.SpaceBasedIdGenerator;
import com.daiwacm.dats.type.Side;

@Ignore
@ContextConfiguration(locations = "classpath:/META-INF/spring/dbunit-jdbc.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class DBUnitTestCfgMgr extends DatabaseTestCase {

	private static final Logger log = LoggerFactory.getLogger(DBUnitTestCfgMgr.class);

	private ConfigManager configManager;
	private ConfigManager genericConfigManager;
    protected GigaSpace cfgGigaSpace;

    @Autowired
    private DataSource dataSource;

    @Before  
    public void init() throws Exception{  
        // insert data into db  
        DatabaseOperation.CLEAN_INSERT.execute(getConnection(), getDataSet());  
        
    	ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("/META-INF/spring/pu-dbunit-cfgmgr.xml");

    	cfgGigaSpace = (GigaSpace)context.getBean("cfgGigaSpace");

    	configManager = (MainConfigManager)context.getBean("configManager");
    	genericConfigManager = (MainConfigManager)context.getBean("genericConfigManager");
    }  
  
    @After  
    public void after() throws Exception{  
        // insert data into db  
        DatabaseOperation.DELETE_ALL.execute(getConnection(), getDataSet());  
    }  

	@Override
	protected IDataSet getDataSet() throws Exception {
		log.info(">>> getDataSet");
		
		log.info("Current directory {}", new File(".").getAbsolutePath());
		
		File file = new File("src/test/resources/dataset-cfg.xml");
		
		return new FlatXmlDataSetBuilder().build(new FileInputStream(file));
	}

	@Override
    public IDatabaseConnection getConnection() throws Exception{  
        return new DatabaseConnection(dataSource.getConnection());  
    } 
    
    @Test
    public void testIdGenerate() {

    	IdCounterEntry id1 = new IdCounterEntry();
    	IdCounterEntry[] ids = cfgGigaSpace.readMultiple(id1, Integer.MAX_VALUE);
    	Assert.assertEquals(3, ids.length);
    	
    	IdGenerator idgFilter = new SpaceBasedIdGenerator(cfgGigaSpace, Filter.class.getName());

    	Assert.assertNotNull(idgFilter);

    	int[] i = new int[18];
    	
    	for (int k=0; k<i.length; k++) {
    		i[k] = idgFilter.generateId();
        	log.info("id {} {}", k, i[k]);
    		Assert.assertTrue(i[k]>0);
    	}
    	for (int k=1; k<i.length; k++) {
    		Assert.assertEquals(i[k]-1, i[k-1]);
    	}
    	
    	
    	log.info("try again >>>");
    	
    	// TODO is following line still needed?
    	new SpaceBasedIdGenerator(cfgGigaSpace, Filter.class.getName());
    	for (int k=0; k<i.length; k++) {
    		i[k] = idgFilter.generateId();
        	log.info("id {} {}", k, i[k]);
    		Assert.assertTrue(i[k]>0);
    	}
    	for (int k=1; k<i.length; k++) {
    		Assert.assertEquals(i[k]-1, i[k-1]);
    	}
    }
    
    @Test
    public void testRead() {
    	log.info("hello testing");

    	Filter t = new Filter();
    	Filter[] fresults = cfgGigaSpace.readMultiple(t, Integer.MAX_VALUE);
    	Assert.assertTrue(fresults.length>5);

    	log.info("number of Filter: {}", fresults.length);
    	for (Filter f : fresults) {
    		log.info("{}", f);
    	}
    	
    	Property pt = new Property();
    	Property[] presults = cfgGigaSpace.readMultiple(pt, Integer.MAX_VALUE);
    	Assert.assertTrue(presults.length>5);

    	log.info("number of Property: {}", presults.length);
    	for (Property p : presults) {
    		log.info("{}", p);
    	}
    }

    @Test
    public void testCfgMgrEval() {
    	Order order = new Order("0005.HK", "POV", Side.SELL, 1000, "LIMIT", 10.0);
    	order.setTrader("simon");
    	configManager.enrichOrder(order);
    }
    
    @Test
    public void testGetProperty() throws Exception {
	    
    	Property pt = genericConfigManager.getProperty("XHKG", "AM_NO_TRADING");
    	
    	Assert.assertNotNull(pt);
    	
    	log.info(pt.toString());
    	
    	Assert.assertEquals("00:00:00 +0800", pt.getPropertyValue());
    }
}

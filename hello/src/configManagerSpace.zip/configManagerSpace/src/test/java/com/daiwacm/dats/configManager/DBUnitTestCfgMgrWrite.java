package com.daiwacm.dats.configManager;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.sql.DataSource;

import org.dbunit.DatabaseTestCase;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.operation.DatabaseOperation;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openspaces.core.GigaSpace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.daiwacm.dats.configManager.MainConfigManager;
import com.daiwacm.dats.configManager.Filter;
import com.daiwacm.dats.configManager.ConfigManager;
import com.daiwacm.dats.configManager.Property;
import com.daiwacm.dats.configManager.util.IdCounterEntry;
import com.daiwacm.dats.configManager.util.IdGenerator;
import com.daiwacm.dats.configManager.util.SpaceBasedIdGenerator;

@Ignore
@ContextConfiguration(locations = "classpath:/META-INF/spring/dbunit-jdbc.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class DBUnitTestCfgMgrWrite extends DatabaseTestCase {

	private static final Logger log = LoggerFactory.getLogger(DBUnitTestCfgMgrWrite.class);

	private ConfigManager configManager;
    protected GigaSpace cfgGigaSpace;

    @Autowired
    private DataSource dataSource;

    @Before  
    public void init() throws Exception{  
        // insert data into db  
        DatabaseOperation.CLEAN_INSERT.execute(getConnection(), getDataSet());  
        
    	ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("/META-INF/spring/pu-dbunit-cfgmgr.xml");

    	cfgGigaSpace = (GigaSpace)context.getBean("cfgGigaSpace");

    	configManager = (MainConfigManager)context.getBean("configManager");
    }  
  
    @After  
    public void after() throws Exception{  
        // insert data into db  
        DatabaseOperation.DELETE_ALL.execute(getConnection(), getDataSet());  
    }  

	@Override
	protected IDataSet getDataSet() throws Exception {
		log.info(">>> getDataSet");
		
		log.info("Current directory {}", new File(".").getAbsolutePath());
		
		File file = new File("src/test/resources/dataset-cfg.xml");
		
		return new FlatXmlDataSetBuilder().build(new FileInputStream(file));
	}

	@Override
    public IDatabaseConnection getConnection() throws Exception {
        return new DatabaseConnection(dataSource.getConnection());  
    }

    @Test
    public void testIdGenerate() {

    	IdCounterEntry id1 = new IdCounterEntry();
    	IdCounterEntry[] ids = cfgGigaSpace.readMultiple(id1, Integer.MAX_VALUE);
    	Assert.assertEquals(3, ids.length);
    	
    	IdGenerator idgFilter = new SpaceBasedIdGenerator(cfgGigaSpace, Filter.class.getName());

    	Assert.assertNotNull(idgFilter);

    	int[] i = new int[18];
    	
    	for (int k=0; k<i.length; k++) {
    		i[k] = idgFilter.generateId();
        	log.info("id {} {}", k, i[k]);
    		Assert.assertTrue(i[k]>0);
    	}
    	for (int k=1; k<i.length; k++) {
    		Assert.assertEquals(i[k]-1, i[k-1]);
    	}
    	
    	log.info("try again >>>");
    	
    	// TODO is following line still needed?
    	new SpaceBasedIdGenerator(cfgGigaSpace, Filter.class.getName());
    	for (int k=0; k<i.length; k++) {
    		i[k] = idgFilter.generateId();
        	log.info("id {} {}", k, i[k]);
    		Assert.assertTrue(i[k]>0);
    	}
    	for (int k=1; k<i.length; k++) {
    		Assert.assertEquals(i[k]-1, i[k-1]);
    	}
    }
    
    @Test
    public void testCfgMgrWrite() {
    	String filterTag = "HSBC_POV2";
    	
    	try {
    		configManager.createFilter(filterTag, "strategy=POV; symbol=0005.HK; qty>400;", "testing");
    		configManager.createProperty("*", filterTag, "StartTime", "10:30 +0800", null, "testing");
    	} catch (Exception e) {
    		e.printStackTrace();
    		Assert.assertTrue(e.getMessage(), false);
    	}
    	
    	Filter ft = new Filter();
    	ft.setFilterId("HSBC_POV2");
    	Filter f = cfgGigaSpace.read(ft, Integer.MAX_VALUE);
    	log.info("Filter:: {}", f.toString());
    	Assert.assertNotNull(f);

    	Property pt = new Property();
    	pt.setFilterId(filterTag);
    	Property p = cfgGigaSpace.read(pt, Integer.MAX_VALUE);

    	log.info("Property:: {}", p.toString());
    	Assert.assertNotNull(p);

    	log.info(p.getFilterId().toString());
    	Assert.assertEquals(filterTag, p.getFilterId());
    	
    	log.info(p.getPropertyTag().toString());
    	Assert.assertEquals("StartTime", p.getPropertyTag().getPropertyId());
    	
    	// query from database
    	try {
    		Assert.assertTrue(queryDB()>0);
    	} catch (Exception e) {
    		e.printStackTrace();
    		assertTrue(false);
    	}
    }
	
    public int queryDB() throws Exception {  
        Connection con = dataSource.getConnection();  
        Statement stmt = con.createStatement();  
        // get current data  
        ResultSet rst = stmt.executeQuery("select * from Filter where filterId='HSBC_POV2'");  
        int n = 0;
        while (rst.next()){  
            log.info(">>>> id {} filter {} conditions {}", new Object[] {rst.getString("id"), rst.getString("filterId"), rst.getString("conditions")});
            n++;
        }
        
        return n;
    }
}

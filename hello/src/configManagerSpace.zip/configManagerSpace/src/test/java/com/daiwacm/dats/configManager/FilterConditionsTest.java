package com.daiwacm.dats.configManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.daiwacm.dats.configManager.common.BaseTest;
import com.daiwacm.dats.configManager.common.Condition;
import com.daiwacm.dats.configManager.common.IConfigurable;
import com.daiwacm.dats.configManager.common.InvalidConditionException;
import com.daiwacm.dats.configManager.common.InvalidDerivationException;
import com.daiwacm.dats.configManager.common.Order;
import com.daiwacm.dats.configManager.common.UnknownFilterTagException;
import com.daiwacm.dats.configManager.common.UnknownOperatorException;
import com.daiwacm.dats.type.Side;


@RunWith(SpringJUnit4ClassRunner.class)
public class FilterConditionsTest extends BaseTest {

	private static final Logger log = LoggerFactory.getLogger(FilterConditionsTest.class);
	
    @Before
    public void before() {
        cfgGigaSpace.clear(null);
    }
	
	@Test
	public void testOperator() {
		assertTrue(Condition.ConditionOperator.GT.eval("ABCD", "ABC"));
		assertTrue(Condition.ConditionOperator.GE.eval("ABCD", "ABC"));
		assertTrue(Condition.ConditionOperator.GE.eval("XXYYZ", "XXYY"));
		assertTrue(Condition.ConditionOperator.LT.eval("AB", "ABC"));
		
		assertTrue(Condition.ConditionOperator.LIKE.eval("AB", Pattern.compile(".*AB.*")));
		assertTrue(Condition.ConditionOperator.LIKE.eval("ABC", Pattern.compile("AB.*")));
		
		Set<String> s = new HashSet<String>(Arrays.asList("XX", "YY", "AB", "ZZ"));
		
		assertTrue(Condition.ConditionOperator.IN.eval("AB", s));
		assertFalse(Condition.ConditionOperator.IN.eval("ABC", s));
		
		BigDecimal v1 = new BigDecimal("0.1");
		BigDecimal v2 = new BigDecimal("0.10");
		BigDecimal v3 = new BigDecimal("0.3");
		BigDecimal v4 = new BigDecimal("1.1");
		
		assertTrue(Condition.ConditionOperator.EQ.eval(v1, v2));
		assertTrue(Condition.ConditionOperator.LT.eval(v1, v4));
		assertTrue(Condition.ConditionOperator.LT.eval(v2, v4));
		assertTrue(Condition.ConditionOperator.LE.eval(v1, v4));

		assertTrue(Condition.ConditionOperator.GT.eval(v4, v3));
		assertTrue(Condition.ConditionOperator.GE.eval(v4, v2));
	}
	
    @Test
    public void testConfigurable() throws Exception {
    	
		Class<?> cls = Class.forName(Order.class.getName());
		
		assertTrue(IConfigurable.class.isAssignableFrom(cls));
		
		final String symbol = "0001.HK";
		IConfigurable obj = (IConfigurable) cls.newInstance();
    	cls.getMethod("setSymbol", String.class).invoke(obj, symbol);
    	assertEquals(symbol, cls.getMethod("getSymbol").invoke(obj));
    }
    
    @Test
    public void testFilterTagDerivation_object() throws InvalidDerivationException {
    	Order order = new Order("0005.HK", "POV", Side.SELL_SHORT, 1000, "LIMIT", 10.0);
    	
    	assertEquals("0005.HK", new FilterTagDerivation(Order.class, "object.symbol").derive(order).toString());
    	assertEquals("SELL_SHORT", new FilterTagDerivation(Order.class, "object.side").derive(order).toString());
    	assertEquals("LIMIT", new FilterTagDerivation(Order.class, "object.orderType").derive(order).toString());
    }
    
    @Test(expected=InvalidDerivationException.class)
    public void testInvalidFilterDerivationPath() throws InvalidDerivationException {
        new FilterTagDerivation(Order.class, "object.sxymbol");
    }

	@Test
	public void testConditionMap() throws Exception {
		writeFilterTags(cfgGigaSpace);

		String cstr1 = "strategy=POV";
		String cstr2 = "symbol<>0001.HK";
		String cstr4 = "ordType=LIMIT";
		
		FilterConditions c = new FilterConditions(configManager, 
    	        cstr1 + ";" + cstr2 + ";" + cstr4);
		
    	assertTrue(c.matches(configManager, new Order("0005.HK", "POV", Side.SELL_SHORT, 1000, "LIMIT", 10.0), true));
    	assertFalse(c.matches(configManager, new Order("0001.HK", "POV", Side.SELL_SHORT, 1000, "LIMIT", 10.0), true));
    	assertFalse(c.matches(configManager, new Order("0005.HK", "VWAP", Side.SELL_SHORT, 1000, "LIMIT", 10.0), true));
    	assertFalse(c.matches(configManager, new Order("0005.HK", "POV", Side.SELL_SHORT, 1000, "MARKET", 10.0), true));
	}
	
	@Test
	public void testConditionEval() throws UnknownOperatorException, UnknownFilterTagException, InvalidConditionException {
		writeFilterTags(cfgGigaSpace);

        log.info("============== test <> ==============");
        Order order = new Order("0005.HK", "VWAP", Side.BUY, 1000, "LIMIT", 0.10);
        FilterConditions c = new FilterConditions(configManager, 
                "strategy=VWAP; symbol<>0001.HK; side<>S; ");
        assertTrue(c.matches(configManager, order, true));
		
		log.info("============== test like and price < ==============");
		order = new Order("0005.HK", "VWAP", Side.BUY, 5000, "LIMIT", 0.10);
		order.setClient("HSBC1");
		c = new FilterConditions(configManager, 
		        "strategy=VWAP; symbol<>0001.HK; client like HSBC%; price<1.0; ");
		assertTrue(c.matches(configManager, order, true));

		log.info("============== test like false ==============");
		order.setClient("MSIM");
		assertFalse(c.matches(configManager, order, true));

		log.info("============== test in ==============");
		c = new FilterConditions(configManager, 
		        "strategy=VWAP; symbol<>0001.HK; client in (HSBC, MSIM,CITI); price<0.5; ");
		assertTrue(c.matches(configManager, order, true));
		
		log.info("============== test in false ==============");
		order.setClient("HSBC1");
		assertFalse(c.matches(configManager, order, true));

		log.info("============== test in wrong format ==============");
		c = new FilterConditions(configManager, 
		        "strategy=VWAP; symbol<>0001.HK; client in (HSBC, MSIM,CITI; price<0.5; ");
		assertFalse(c.matches(configManager, order, true));
	}
}
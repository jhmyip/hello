package com.daiwacm.dats.configManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.daiwacm.dats.configManager.common.BaseTest;
import com.daiwacm.dats.configManager.util.ConfigUtils;

@DirtiesContext(classMode=ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringJUnit4ClassRunner.class)
public class FilterTagTest extends BaseTest {
    
    @SuppressWarnings("unused")
	private static final Logger log = LoggerFactory.getLogger(FilterTagTest.class);

	@Before
    public void clearSpace() {
        cfgGigaSpace0.clear(null);
        cfgGigaSpace.clear(null);
    }

    @Test
    public void countFilterTag() {
        int filterTagCount = writeFilterTags(cfgGigaSpace);
        configManager.init();

    	assertEquals(filterTagCount, cfgGigaSpace.count(new FilterTag(), Integer.MAX_VALUE));
    	assertEquals(filterTagCount, configManager.getFilterTagCount());
    }
    
    @Test
    public void testFilterTag() {
    	FilterTag ftp = new FilterTag(9, "region", new BigDecimal("1.1"), 
    			"com.daiwacm.dats.configManager.common.Stock.getRegion", 
    			"testing", ConfigUtils.getDate(2010,11,11), 'Y', "dbo");
    	cfgGigaSpace.write(ftp);
        
    	assertEquals(1, cfgGigaSpace.count(new FilterTag(), Integer.MAX_VALUE));
    }

    @Test
    public void countFilterTag2() {
        
        clearSpace();
        
        Set<Integer> set = new HashSet<Integer>();
        set.add(10);
        set.add(11);
        set.add(12);
        
        for (FilterTag t : cfgGigaSpace.readMultiple(new FilterTag(), Integer.MAX_VALUE)) {
            set.add(t.getId());
        }

        cfgGigaSpace.write(new FilterTag(10, "region", new BigDecimal(1.0), 
    			"com.daiwacm.dats.configManager.common.Stock.getRegion", 
    			"testing", ConfigUtils.getDate(2010,11,11), 'Y', "dbo"));

        cfgGigaSpace.write(new FilterTag(11, "country", new BigDecimal(2.0), 
    			"com.daiwacm.dats.configManager.common.Stock.getCountry", 
    			"testing", ConfigUtils.getDate(2010,11,11), 'Y', "dbo"));

        cfgGigaSpace.write(new FilterTag(12, "exchange", new BigDecimal(3.0), 
    			"com.daiwacm.dats.configManager.common.Stock.getExchange", 
    			"testing", ConfigUtils.getDate(2010,11,11), 'Y', "dbo"));
    	
    	configManager.init();
    	
    	assertEquals(2, configManager.getFilterTagCount());
    	assertEquals(12, configManager.getFilterTag("exchange").getId().intValue());
    	
    	for (FilterTag pp1 : cfgGigaSpace.readMultiple(new FilterTag(), Integer.MAX_VALUE)) {
    		if (!set.contains(pp1.getId())) {
    		    fail("id unexpected: " + pp1.getId());
    		}
    		
			set.remove(pp1.getId().intValue());
    	}
    	
    	assertTrue(set.isEmpty());
    }
}

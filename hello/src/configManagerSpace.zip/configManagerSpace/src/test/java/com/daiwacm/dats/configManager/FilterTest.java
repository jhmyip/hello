package com.daiwacm.dats.configManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openspaces.core.GigaSpace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.daiwacm.dats.configManager.common.BaseTest;
import com.daiwacm.dats.configManager.common.Order;
import com.daiwacm.dats.configManager.util.ConfigUtils;
import com.daiwacm.dats.type.Side;

@DirtiesContext(classMode=ClassMode.AFTER_EACH_TEST_METHOD)
@RunWith(SpringJUnit4ClassRunner.class)
public class FilterTest extends BaseTest {
    
    private static final Logger log = LoggerFactory.getLogger(FilterTest.class);
    
    @Before
    public void clearSpace() throws Exception {
        cfgGigaSpace0.clear(null);
        cfgGigaSpace.clear(null);
		writeFilterTags(cfgGigaSpace);
        writeFilterProperty(cfgGigaSpace);
    	writeFilterProperty2(cfgGigaSpace);
//        configManager.init();
        Thread.sleep(500);
    }
    
    private static void writeFilterProperty(GigaSpace gigaSpace) {
        Filter f1 = new Filter(1, "HSBC_VWAP", "strategy=VWAP; symbol=0005.HK; ", "testing");
        Filter f2 = new Filter(2, "CK_VWAP", "strategy=VWAP; symbol=0001.HK;", "testing");
        Filter f3 = new Filter(3, "HSBC_POV", "strategy=POV; symbol=0005.HK;", "testing");
        Filter f4 = new Filter(4, "POVSS", "strategy=POV; side=SELL_SHORT;", "testing");

        gigaSpace.write(f1);
        gigaSpace.write(f2);

        PropertyTag tag1 = new PropertyTag(6064, "MaxVol", "Max%Vol"); 
        PropertyTag tag2 = new PropertyTag(6065, "ExecStyle", "ExecStyle"); 
        PropertyTag tag3 = new PropertyTag(6223, "Field1", "moo");
        PropertyTag tag4 = new PropertyTag(6067, "MinVol", "Min%Vol");
        
        Property pp11 = new Property(11, f1.getFilterId(), "*", tag2, "1", "trading style for hsbc POV");
        Property pp12 = new Property(12, f1.getFilterId(), "*", tag1, "20", "max_vol_cap for hsbc POV");
        Property pp13 = new Property(13, f1.getFilterId(), "*", tag3, "Y", "moo part for hsbc POV");
        Property pp14 = new Property(14, f1.getFilterId(), "*", tag4, "5", "min vol %");

        gigaSpace.write(pp11);
        gigaSpace.write(pp12);
        gigaSpace.write(pp13);
        gigaSpace.write(pp14);

        DateFormat df = new SimpleDateFormat("yyyyMMdd");

        Property pp21 = new Property(21, f2.getFilterId(), "*", tag2, "3", "trading style for CK POV");
        Property pp22 = new Property(22, f2.getFilterId(), "*", tag1, "30", "max_vol_cap for CK POV", 'Y', ConfigUtils.getDate(2011, 1, 1), ConfigUtils.getDate(2080, 1, 1));
        try {
            Property pp23 = new Property(23, f2.getFilterId(), "*", tag1, "35", "max_vol_cap for CK POV", 'Y', df.parse("20110112"), df.parse("20110115"));
            gigaSpace.write(pp23);
        } catch (Exception e) {
            e.printStackTrace();
        }

        gigaSpace.write(pp21);
        gigaSpace.write(pp22);

        Property pp31 = new Property(31, f3.getFilterId(), "*", tag2, "3", "trading sytle");
        Property pp32 = new Property(32, f3.getFilterId(), "*", tag1, "30", "max_vol_cap ");
        gigaSpace.write(pp31);
        gigaSpace.write(pp32);

        Property pp41 = new Property(41, f4.getFilterId(), "*", tag1, "33", "max_vol_cap ");
        gigaSpace.write(pp41);

        gigaSpace.write(f1);
        gigaSpace.write(f2);
        gigaSpace.write(f3);
        gigaSpace.write(f4);
    }

    private static void writeFilterProperty2(GigaSpace gigaSpace) {
        Filter f1 = new Filter(1, "HS_VWAP", "strategy=VWAP; symbol in (0005.HK, 0011.HK); ", "testing");

        gigaSpace.write(f1);

        PropertyTag tag1 = new PropertyTag(6064, "MaxVol", "Max%Vol"); 
        PropertyTag tag2 = new PropertyTag(6065, "ExecStyle", "ExecStyle"); 
        
        Property pp11 = new Property(11, f1.getFilterId(), "*", tag2, "2", "trading style for hsbc ");
        Property pp12 = new Property(12, f1.getFilterId(), "*", tag1, "21", "max_vol_cap for hsbc ");

        gigaSpace.write(pp11);
        gigaSpace.write(pp12);

        gigaSpace.write(f1);
    }

    @Test
    public void testFilterEval() throws Exception {
        Filter[] results = cfgGigaSpace.readMultiple(new Filter(), Integer.MAX_VALUE);
        assertEquals(4, results.length);
        
        Order order = new Order("0005.HK", "VWAP", Side.BUY, 500, "LIMIT", 0.10);
        log.info("order: {}", order);
        log.info("filter# {}", configManager.getFilterIdToFilterMap().size());
        Assert.assertTrue("filer# shouldn't be zero", configManager.getFilterIdToFilterMap().size()>0);
        
        int passed=0;
        // evaluate filter
        for (Filter filter : configManager.getFilterIdToFilterMap().values()) {
            boolean r = filter.matches(configManager, order, true);
            
            log.info("matching: {} - {}", filter.getConditions(), r);
            
            if (filter.getFilterId().contains("HSBC_VWAP") || filter.getFilterId().contains("HS_VWAP")) {
                assertTrue(r);
                passed++;
            } else {
                assertFalse(r);
            }
        }
        assertTrue("should get at lease one filter passed", passed>0);
    }
    
    @Test
    public void testFilterEvalSS() {
        Filter[] results = cfgGigaSpace.readMultiple(new Filter(), Integer.MAX_VALUE);
        assertEquals(4, results.length);
        
        Order order = new Order("0006.HK", "POV", Side.SELL_SHORT, 500, "LIMIT", 0.10);
        
        // evaluate filter
        for (Filter filter : configManager.getFilterIdToFilterMap().values()) {
            log.info("filter [{}]", filter);
            boolean r = filter.matches(configManager, order, true);
            
            log.info(filter.getConditions() + " - " + r);
            
            if (filter.getFilterId().contains("POVSS")) {
                assertTrue(r);
            } else {
                assertFalse(r);
            }
        }
    }
}

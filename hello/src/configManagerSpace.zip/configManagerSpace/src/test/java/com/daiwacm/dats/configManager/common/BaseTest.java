package com.daiwacm.dats.configManager.common;

import java.math.BigDecimal;

import org.junit.Ignore;
import org.openspaces.core.GigaSpace;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.daiwacm.dats.configManager.MainConfigManager;
import com.daiwacm.dats.configManager.FilterTag;

@ContextConfiguration(locations = "classpath:/META-INF/spring/pu-unittest.xml")
@Ignore
public class BaseTest {
    
    @Autowired
    protected MainConfigManager configManager;
    
    @Autowired
    protected GigaSpace cfgGigaSpace;

    @Autowired
    protected GigaSpace cfgGigaSpace0;
    
    protected int writeFilterTags(GigaSpace gigaSpace) {

        String[][] filterTags = {
            {"region", "1", "object.product.region"},
            {"country", "2", "object.product.countryCode"},
            {"exchange", "3", "object.product.exch"},
            {"venue", "4", "object.venue"},
            {"strategy", "5", "object.strategy"},
            {"client", "6", "object.client"},
            {"trader", "7", "object.trader"},
            {"sector", "8", "object.product.sector"},
            {"mktcap", "8.1", "object.product.marketCap"},
            {"qty", "8.3", "object.qty"},
            {"symbol", "9", "object.symbol"},
            {"side", "10", "object.side"},
            {"price", "10.2", "object.price"},
            {"ordType", "11", "object.orderType"}
        };
        
        int id=1;
        for (String[] ft : filterTags) {
            FilterTag ftp = new FilterTag(id++, ft[0], new BigDecimal(ft[1]), ft[2], "testing" );
            gigaSpace.write(ftp);
        }
        
        configManager.init();
    
        return filterTags.length;
    }
}

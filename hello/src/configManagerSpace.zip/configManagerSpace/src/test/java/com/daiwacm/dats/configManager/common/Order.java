package com.daiwacm.dats.configManager.common;

import quickfix.Message;

import com.daiwacm.dats.refdata.model.interfaces.Product;
import com.daiwacm.dats.type.Side;

public class Order implements IConfigurable {

	private String symbol;
	private String strategy;
	private Integer qty;
	private String orderType;
	private String client;
	private String trader;
	private String venue;
	private Side side;
	private Double price;
	private String region;
	private String country;
	private String exchange;
	private String sector;
	private Product prd;
	private String execStyle;
	private String maxVol;
	
	private Message customFields;
	
	public Order() { }
	
	public Order(String symbol, String strategy, Side side, Integer qty, String orderType, double price) {
		this.symbol = symbol;
		this.strategy = strategy;
		this.qty = qty;
		this.orderType = orderType;
		this.side = side;
		this.price = price;
		this.region = "HK";
		this.country = "HK";
		this.exchange = "XHKG";
		this.venue = "HKEX";
		
		customFields = new quickfix.Message();
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getStrategy() {
		return strategy;
	}

	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getTrader() {
		return trader;
	}

	public void setTrader(String trader) {
		this.trader = trader;
	}

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}

	public Side getSide() {
		return side;
	}

	public void setSide(Side side) {
		this.side = side;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setExchange(String exchange) {
		this.exchange = exchange;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getRegion() { return region; }

	@ConfigurableTag(tagName="country")
	public String getCountry() { return country; }
	
	@ConfigurableTag
	public String getExchange() { return exchange; }

	public String getSector() { return sector; }
	
	@Override
	public String toString() {
		return "Order [" + side + " " + symbol + ", " + strategy + ", qty=" + qty + " @ " + price
				+ ", orderType=" + orderType + ", client=" + client + ", trader=" + trader 
				+ ", venue=" + venue + ", region=" + region + ", country="
				+ country + ", exchange=" + exchange + ", sector=" + sector + "]";
	}

	public static String getVenue(Order o) { return o.getVenue(); }

	public static String getTrader(Order o) { return o.getTrader(); }
	
	public static Double getPrice(Order o) { return o.getPrice(); }
	
	public static Integer getQty(Order o) { return o.getQty(); }
	
	// the result value can be String/Double/Integer
	public static Object getOrderInfo(Order o, String param) {
		if (param.equalsIgnoreCase("side")) {
			return o.getSide();
		} else if (param.equalsIgnoreCase("client")) {
			return o.getClient();
		} else if (param.equalsIgnoreCase("price")) {
			return o.getPrice();
		} else if (param.equalsIgnoreCase("qty")) {
			return o.getQty();
		} else {
		    return null;
		}
	}

	public void setProduct(Product p) {
		prd = p;
	}

	@Override
	public Product getProduct() {
		return prd;
	}

	@ConfigurableProperty(propertyName="ExecStyle")
	public void setExecStyle(String es) {
		execStyle = es;
	}
	
	public String getExecStyle() {
		return execStyle;
	}
	
	@ConfigurableProperty
	public void setMaxVol(String mv) {
		maxVol = mv;
	}

	public String getMaxVol() {
		return maxVol;
	}

	@Override
	public String getField(int field) {
        try {
            return customFields.getString(field);
        } catch (Exception e) {
            return null;
        }
	}

	@Override
	public void setField(int field, String value) {
        customFields.setString(field, value);
	}
}

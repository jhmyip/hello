package com.daiwacm.dats.configManager.common;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;

@Entity
@Table(name="TestChild")
@SpaceClass
public class TestChild implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    
    private String name;
    
    private Integer parentId;
    
	private TestParent parent;
    
    public TestChild() {}

	@Id 
    @SpaceId(autoGenerate = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(insertable=false, updatable=false)
    public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	
	@ManyToOne 
	@JoinColumn(name = "parentId", referencedColumnName = "id")
	public TestParent getParent() {
		return parent;
	}

	public void setParent(TestParent parent) {
		this.parent = parent;
	} 
    
	@Override
	public String toString() {
		return this.hashCode() + ":" + this.getId() + ":" + this.getName() + " - parentId " + this.parentId;
	}
	
	@Override
	public boolean equals(Object obj) {
		return this.hashCode()==obj.hashCode();
	}

	@Override
	public int hashCode() {
		return (id+" ").hashCode();
	}
}

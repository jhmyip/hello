package com.daiwacm.dats.configManager.common;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigaspaces.annotation.pojo.SpaceId;
import com.gigaspaces.annotation.pojo.SpaceRouting;

@Entity
@Table(name="TestEntry")
public class TestEntry {
    private Integer id;
    
    private String name;

    public TestEntry() {}
    
	public TestEntry(Integer id, String name) {
		this.id = id;
		this.name = name;
	}

	@Id 
    @SpaceId(autoGenerate = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@SpaceRouting
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.hashCode() + ":" + this.getId() + ":" + this.getName();
	}

	@Override
	public boolean equals(Object obj) {
		return this.hashCode()==obj.hashCode();
	}

	@Override
	public int hashCode() {
		return (id + name).hashCode();
	}
}

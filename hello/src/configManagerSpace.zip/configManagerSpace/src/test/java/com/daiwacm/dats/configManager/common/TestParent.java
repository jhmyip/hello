package com.daiwacm.dats.configManager.common;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gigaspaces.annotation.pojo.SpaceClass;
import com.gigaspaces.annotation.pojo.SpaceId;

@Entity
@Table(name="TestParent")
@SpaceClass
public class TestParent implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;
    
    private String name;

    private Set<TestChild> children = null;

    public TestParent() {}
    
    @Id 
    @SpaceId(autoGenerate = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@OneToMany(mappedBy = "parent", fetch = FetchType.EAGER)
	public Set<TestChild> getChildren() {
		return children;
	}

	public void setChildren(Set<TestChild> children) {
		this.children = children;
	}

	@Override
	public String toString() {
		return this.hashCode() + ":" + this.getId() + ":" + this.getName();
	}
}
package com.daiwacm.dats.configManager.util;


import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.openspaces.core.GigaSpace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.daiwacm.dats.configManager.Filter;
import com.daiwacm.dats.configManager.FilterTag;
import com.daiwacm.dats.configManager.Property;
import com.daiwacm.dats.configManager.PropertyTag;
import com.daiwacm.dats.configManager.common.UnConfigurableException;



public class TestDataInitializer {
	private static final Logger log = LoggerFactory.getLogger(TestDataInitializer.class);

	@Autowired
	@Qualifier("cfgGigaSpace")
    private GigaSpace gigaSpace;
	
	private List<List<String>> filters;
	private List<List<String>> propertyTags;
	private List<List<String>> properties;
	private List<List<String>> filterTags;
	
	public void setFilters(List<List<String>> filters) {
		this.filters = filters;
	}

	public void setPropertyTags(List<List<String>> propertyTags) {
		this.propertyTags = propertyTags;
	}

	public void setProperties(List<List<String>> properties) {
		this.properties = properties;
	}

	public void setFilterTags(List<List<String>> filterTags) {
		this.filterTags = filterTags;
	}

    public void setGigaSpace(GigaSpace gigaSpace) {
        this.gigaSpace = gigaSpace;
    }

	@PostConstruct
    public void init() throws UnConfigurableException {
    	log.debug("Init test data:");
    	
		int ftid=1;
		for (List<String> ft : filterTags) {
			FilterTag ftp = new FilterTag(ftid++, ft.get(0), new BigDecimal(ft.get(1)), ft.get(2), "testing" );
			gigaSpace.write(ftp);
		}
    	log.debug(">>> set {} filterTags", ftid-1);
    	
    	Map<String, Filter> fMap = new HashMap<String, Filter>();
    	Map<String, PropertyTag> ptMap = new HashMap<String, PropertyTag>();
    	
    	int fid = 1;
    	for (List<String> fs : filters) {
    		Filter f = new Filter(fid++, fs.get(0), fs.get(1), fs.get(2));
    		gigaSpace.write(f);
    		fMap.put(fs.get(0), f);
    	}
    	log.debug(">>> set {} filters", fid-1);

    	for (List<String> pts : propertyTags) {
    		PropertyTag tag = new PropertyTag(Integer.parseInt(pts.get(0)), pts.get(1), pts.get(2));
    		gigaSpace.write(tag);
    		ptMap.put(pts.get(1), tag);
    	}
    	
    	DateFormat df = new SimpleDateFormat("yyyyMMdd");

    	int pid = 1;
    	for (List<String> ps : properties) {
    		Filter f = fMap.get(ps.get(0));
    		Property p=null;
    		if (ps.size()>4) {
    			Character override=null;
   			 
    			if (ps.get(3)!=null) {
    				override=ps.get(3).charAt(0);
    			}
        		try {
        			p = new Property(pid++, f.getFilterId(), "*", ptMap.get(ps.get(1)), ps.get(2), ps.get(6), override, df.parse(ps.get(4)), df.parse(ps.get(5)));
        		} catch (Exception e) {
        			e.printStackTrace();
        		}

    		} else {
    			p = new Property(pid++, f.getFilterId(), "*", ptMap.get(ps.get(1)), ps.get(2), ps.get(3));
    		}
    		gigaSpace.write(p);
    	}
    	log.debug(">>> set {} properties", pid-1);

    	logAllEntries(gigaSpace);
    }

    public static void logAllEntries(GigaSpace cfgGigaSpace) {
    	log.debug("FilterTag {}", cfgGigaSpace.readMultiple(new FilterTag(), Integer.MAX_VALUE));
    	log.debug("Filter {}", cfgGigaSpace.readMultiple(new Filter(), Integer.MAX_VALUE));
    	log.debug("PropertyTag {}", cfgGigaSpace.readMultiple(new PropertyTag(), Integer.MAX_VALUE));
    	log.debug("Property {}", cfgGigaSpace.readMultiple(new Property(), Integer.MAX_VALUE));
    }

}
